# Product Requirement Document (PRD)

## Project Title
**AI-Based Real-Time Object Detection and Tracking System**

**Academic & Engineering Standard**: Final Year Computer Science & Engineering Capstone Project  
**Version**: 1.0.0  
**Document Status**: Approved  
**Author**: Full Stack AI & Computer Vision Engineering Team  

---

## 1. Executive Summary
The **AI-Based Real-Time Object Detection and Tracking System** is an enterprise-grade Computer Vision and SaaS Analytics platform designed for automated surveillance, security monitoring, and intelligent video telemetry. Utilizing state-of-the-art Deep Learning models (**YOLOv8**) coupled with multi-object tracking algorithms (**ByteTrack**), the system detects, classifies, assigns persistent identifiers, and traces spatio-temporal trajectories of objects across both live camera feeds and pre-recorded video files.

The platform provides a high-performance Python FastAPI backend, normalized SQL data storage, an interactive React-based SaaS dashboard strictly adhering to the project's brand design system, comprehensive analytics visualization using Chart.js, and exportable PDF/CSV regulatory audit reports.

---

## 2. Objectives & Scope

### 2.1 Core Objectives
1. **Real-Time Detection & Multi-Object Tracking**: Detect multiple classes with high confidence and maintain persistent tracking IDs without ID-switching during occlusion or frame-to-frame movement.
2. **Dual Stream Ingestion**: Support both client-side browser webcam streaming (via low-latency WebSockets) and file-based video uploads (`.mp4`, `.avi`, `.mov`).
3. **Comprehensive Data Telemetry**: Log every detection instance including bounding box coordinates ($x_1, y_1, x_2, y_2$), confidence score, frame number, timestamp, trajectory history, and snapshot preview.
4. **Visual Analytics & Insights**: Present interactive time-series trends (daily, weekly, monthly), category breakdowns, and system performance metrics (FPS, inference latency).
5. **Auditing & Reporting**: Enable on-demand generation of formal PDF and CSV inspection reports containing statistical summaries and tabular records.
6. **Enterprise SaaS UI/UX**: Deliver a clean, minimal, glassmorphic dashboard with 12px rounded borders, high contrast accessibility, and responsive layouts matching the corporate brand guidelines.

### 2.2 Target Object Classes (COCO Subset & Expanded)
The system is optimized for key urban, domestic, and commercial surveillance classes:
- **People**: Person
- **Vehicles**: Car, Bike (Bicycle/Motorcycle), Bus, Truck
- **Animals**: Dog, Cat
- **Electronics & Workplace**: Laptop, Mobile Phone
- **Indoor Objects**: Chair, Bottle
*(Full 80 COCO classes are supported with configurable runtime filtering)*.

---

## 3. User Roles & Access Control

The platform enforces Role-Based Access Control (RBAC):
- **Administrator (`admin`)**:
  - Full access to all modules, system configurations, and database management.
  - Ability to view all users' videos, sessions, and activity audit logs.
  - Ability to adjust global AI hyperparameters (confidence threshold, NMS IoU threshold, tracker weights).
- **Standard User (`user`)**:
  - Manage personal account profile and credentials.
  - Stream live webcam feed and capture detection snapshots.
  - Upload, play, process, and delete personal videos.
  - Search, filter, and inspect detection history and personal analytics.
  - Generate and download customized PDF/CSV reports.

---

## 4. System Architecture

```
+-------------------------------------------------------------------------+
|                              Frontend Client                            |
|        (React 18 + Vite + Vanilla CSS + Lucide Icons + Chart.js)        |
+--------------------+--------------------------------+-------------------+
                     | HTTP / REST (JWT Auth)         | WebSockets (Frames)
                     v                                v
+--------------------+--------------------------------+-------------------+
|                         FastAPI Application Server                      |
|                                                                         |
|  +------------------+  +-------------------+  +-----------------------+ |
|  | Routers & Auth   |  | Video Processor   |  | WebSocket Controller  | |
|  +--------+---------+  +---------+---------+  +-----------+-----------+ |
|           |                      |                        |             |
|  +--------v----------------------v------------------------v-----------+ |
|  |                   AI Engine (YOLOv8 + ByteTrack)                   | |
|  |  - Object Detection (YOLOv8n/s)                                     | |
|  |  - Multi-Object Tracking & Kalman Filter (ByteTrack)               | |
|  |  - Trajectory Spatio-temporal Calculation                          | |
|  +-------------------------------+------------------------------------+ |
+----------------------------------|--------------------------------------+
                                   | SQLAlchemy ORM
                                   v
+----------------------------------+--------------------------------------+
|                     Database & File Storage                             |
|  - MySQL Database (Tables: users, videos, detections, tracking, etc.)   |
|  - File System (Uploads, Processed Videos, Snapshots, PDF Reports)      |
+-------------------------------------------------------------------------+
```

---

## 5. Functional Module Specifications

### Module 1: Authentication & User Management
- **User Registration**: Username, full name, email, password (hashed with bcrypt/argon2).
- **User Login**: Secure OAuth2 Password Bearer flow issuing JSON Web Tokens (JWT).
- **Forgot Password**: Password reset workflow with token verification.
- **Profile Management**: Update user profile information and change passwords.
- **Session Management**: Automatic token persistence and logout invalidation.

### Module 2: Dashboard
- **KPI Metrics Cards**:
  - Total Videos Uploaded & Processed
  - Total Objects Detected
  - Active Camera Status
  - Detection Accuracy (Average Confidence %)
- **Interactive Visualizations**:
  - Real-time detection volume trend chart.
  - Object class distribution breakdown.
- **Recent Activities Table**: Live-updated feed of recent detections and video uploads.
- **Quick Action Triggers**: Instant buttons to launch live stream, upload video, or export reports.

### Module 3: Video Management
- **File Ingestion**: Multi-format video uploader (`.mp4`, `.avi`, `.mov`) with client-side drag-and-drop and progress bar.
- **Video Catalog**: Card/Table view showing video thumbnail, duration, file size, upload timestamp, and status (`uploaded`, `processing`, `completed`, `failed`).
- **Video Processing Pipeline**:
  - Asynchronous background task running OpenCV frame extraction, YOLOv8 inference, and ByteTrack assignment.
  - Video re-encoding with annotated bounding boxes, class labels, and tracking IDs.
- **Playback & Telemetry**: Embedded HTML5 player with frame-level playback, side-by-side mode, and detection timeline.
- **Deletion**: Secure removal of source file, processed video, and associated detection records.

### Module 4: Live Camera & Streaming
- **Live Video Ingestion**:
  - HTML5 MediaDevices API capturing client webcam stream.
  - Frame transmission over WebSockets with base64 JPEG encoding.
  - Server-side OpenCV capture fallback for physical or RTSP streams.
- **Real-Time Visual Overlay**:
  - Canvas overlay rendering color-coded bounding boxes, class names, confidence percentages, and tracking IDs.
  - Object trajectory path rendering (breadcrumbs/lines tracking movement across recent frames).
- **Live Telemetry HUD**: Active object counter, instantaneous FPS, and inference latency in milliseconds.
- **Snapshot Capture**: On-demand frame snapshot saving annotated image to detection history.

### Module 5: AI Detection & Tracking Engine
- **YOLOv8 Architecture**: Feature extractor (CSPDarknet), Path Aggregation Network (PANet), and decoupled anchor-free head.
- **ByteTrack Integration**:
  - High-confidence and low-confidence detection association via Kalman Filter state prediction and Hungarian matching.
  - Prevents ID switches during occlusions and crossing paths.
- **Object Metadata Computation**:
  - Start Time, End Time, Total Visible Duration (seconds).
  - Spatial Center Coordinates $(C_x, C_y)$ stored as ordered path sequence.

### Module 6: Detection History & Inspection
- **Data Table**: Columns for Snapshot, Object Class, Tracking ID, Confidence, Frame Number, Source (Video/Live), and Timestamp.
- **Search & Filtering**:
  - Search by Object Name or Tracking ID.
  - Filter by Date Range, Specific Object Category, and Confidence Threshold slider.
- **Sorting & Pagination**: Dynamic column sorting and paginated browsing (10, 25, 50 rows).
- **Modal Detail View**: High-resolution view of snapshot with exact bounding box coordinates.

### Module 7: Analytics & Data Visualization
- **Temporal Analysis**: Daily, Weekly, and Monthly detection frequencies.
- **Categorical Analysis**: Bar and Doughnut charts illustrating object type frequencies.
- **Statistical KPIs**: Most frequently detected object, peak activity hours, and mean confidence score.

### Module 8: Reporting & Auditing
- **PDF Report Generation**:
  - Formatted using ReportLab.
  - Professional brand header (#2563EB), summary statistics table, and formatted tabular detection log.
- **CSV Export**: RFC 4180 compliant CSV stream containing all filtered or total detection records.
- **Report Archives**: Downloadable list of previously compiled reports.

### Module 9: System Settings & Configuration
- **Camera Configuration**: Resolution (720p, 1080p), Target FPS (15, 30), Camera Index.
- **AI Hyperparameters**: Confidence threshold slider (0.1 to 1.0), NMS IoU threshold slider (0.1 to 1.0).
- **Target Class Filter**: Checklist allowing users to enable or disable specific classes.
- **System Health**: Backend API status, DB connection health, GPU/CPU execution mode indicator.

---

## 6. Database Schema (Normalized Relational Design)

### 6.1 Entity Relationship Diagram (ERD)
- `users` (1) ---> (M) `videos`
- `users` (1) ---> (M) `reports`
- `users` (1) ---> (M) `activity_logs`
- `videos` (1) ---> (M) `tracking_sessions`
- `tracking_sessions` (1) ---> (M) `tracking_objects`
- `tracking_sessions` (1) ---> (M) `detections`
- `tracking_objects` (1) ---> (M) `detections`

### 6.2 Table Specifications
1. **`users`**:
   - `id` (INT PK AI), `username` (VARCHAR 50 UNIQUE), `email` (VARCHAR 100 UNIQUE), `hashed_password` (VARCHAR 255), `full_name` (VARCHAR 100), `role` (ENUM 'admin', 'user'), `created_at` (DATETIME), `updated_at` (DATETIME).
2. **`videos`**:
   - `id` (INT PK AI), `user_id` (INT FK), `filename` (VARCHAR 255), `original_name` (VARCHAR 255), `filepath` (VARCHAR 500), `file_size` (BIGINT), `duration` (FLOAT), `resolution` (VARCHAR 20), `status` (VARCHAR 20), `processed_filepath` (VARCHAR 500), `fps` (FLOAT), `total_frames` (INT), `created_at` (DATETIME).
3. **`tracking_sessions`**:
   - `id` (INT PK AI), `source_type` (ENUM 'live', 'video'), `video_id` (INT FK NULL), `session_name` (VARCHAR 100), `start_time` (DATETIME), `end_time` (DATETIME NULL), `total_objects` (INT DEFAULT 0), `created_at` (DATETIME).
4. **`tracking_objects`**:
   - `id` (INT PK AI), `session_id` (INT FK), `tracking_id` (INT), `object_class` (VARCHAR 50), `first_detected_at` (DATETIME), `last_detected_at` (DATETIME), `duration_seconds` (FLOAT), `trajectory_data` (JSON), `avg_confidence` (FLOAT).
5. **`detections`**:
   - `id` (INT PK AI), `session_id` (INT FK), `tracking_object_id` (INT FK NULL), `tracking_id` (INT), `object_class` (VARCHAR 50), `confidence` (FLOAT), `frame_number` (INT), `timestamp` (DATETIME), `bbox_x1` (FLOAT), `bbox_y1` (FLOAT), `bbox_x2` (FLOAT), `bbox_y2` (FLOAT), `snapshot_path` (VARCHAR 500 NULL), `created_at` (DATETIME).
6. **`reports`**:
   - `id` (INT PK AI), `user_id` (INT FK), `title` (VARCHAR 100), `report_type` (ENUM 'pdf', 'csv'), `file_path` (VARCHAR 500), `date_range_start` (DATETIME NULL), `date_range_end` (DATETIME NULL), `filters_applied` (JSON), `created_at` (DATETIME).
7. **`activity_logs`**:
   - `id` (INT PK AI), `user_id` (INT FK), `action` (VARCHAR 100), `module` (VARCHAR 50), `details` (TEXT), `ip_address` (VARCHAR 45), `created_at` (DATETIME).

---

## 7. Non-Functional Requirements

1. **Performance & Latency**:
   - Live camera WebSocket frame processing < 60ms latency per frame on CPU (YOLOv8n).
   - Video processing throughput >= 25 FPS on modern multi-core systems.
2. **Reliability & Error Handling**:
   - Graceful fallback when camera is disconnected or unsupported video format is provided.
   - Database auto-reconnect and transaction rollback on failure.
3. **Security**:
   - Passwords hashed using bcrypt with work factor >= 12.
   - JWT tokens signed with HMAC-SHA256 and expiration enforcement.
   - Input sanitization against SQL injection and Path Traversal.
4. **Usability & Brand Compliance**:
   - 100% compliant with Brand Guidelines: Primary `#2563EB`, Secondary `#0F172A`, 12px border radius, Poppins & Inter typography, Lucide icons only.

---

## 8. Verification & Acceptance Criteria
- [x] Successful user authentication with JWT token issuance.
- [x] Real-time detection and tracking on live webcam with persistent IDs and trajectory rendering.
- [x] Successful upload, playback, and asynchronous AI processing of `.mp4` video.
- [x] Accurate population of Detection History with search, filter, and pagination.
- [x] Correct calculation and rendering of analytics graphs in Chart.js.
- [x] Valid generation and downloading of branded PDF and CSV reports.
- [x] Complete installation and running documentation for academic evaluation.

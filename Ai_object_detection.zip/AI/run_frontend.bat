@echo off
title VisionTrack AI - React Frontend Dashboard
echo ===================================================
echo VisionTrack AI Frontend Dashboard (React + Vite)
echo ===================================================
cd /d "%~dp0frontend"
npm.cmd run dev
pause

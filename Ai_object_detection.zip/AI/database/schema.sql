-- =====================================================================
-- AI-Based Real-Time Object Detection and Tracking System
-- MySQL Normalized Database Schema
-- Compatible with MySQL 8.0+ / MariaDB 10.5+
-- =====================================================================

CREATE DATABASE IF NOT EXISTS ai_tracking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ai_tracking;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    hashed_password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user' NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_user_username (username),
    INDEX idx_user_email (email)
) ENGINE=InnoDB;

-- 2. Videos Table
CREATE TABLE IF NOT EXISTS videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    filepath VARCHAR(500) NOT NULL,
    file_size BIGINT DEFAULT 0 NOT NULL,
    duration FLOAT DEFAULT 0.0,
    resolution VARCHAR(20) DEFAULT 'unknown',
    fps FLOAT DEFAULT 0.0,
    total_frames INT DEFAULT 0,
    status ENUM('uploaded', 'processing', 'completed', 'failed') DEFAULT 'uploaded' NOT NULL,
    processed_filepath VARCHAR(500) NULL,
    error_message TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_video_user (user_id),
    INDEX idx_video_status (status)
) ENGINE=InnoDB;

-- 3. Tracking Sessions Table (Live streams or video runs)
CREATE TABLE IF NOT EXISTS tracking_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    source_type ENUM('live', 'video') NOT NULL,
    video_id INT NULL,
    session_name VARCHAR(100) NOT NULL,
    start_time DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_time DATETIME NULL,
    total_objects INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE SET NULL,
    INDEX idx_session_user (user_id),
    INDEX idx_session_source (source_type)
) ENGINE=InnoDB;

-- 4. Tracking Objects Table (Persistent objects with unique tracking ID)
CREATE TABLE IF NOT EXISTS tracking_objects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    tracking_id INT NOT NULL,
    object_class VARCHAR(50) NOT NULL,
    first_detected_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_detected_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    duration_seconds FLOAT DEFAULT 0.0,
    trajectory_data JSON NULL,
    avg_confidence FLOAT DEFAULT 0.0,
    FOREIGN KEY (session_id) REFERENCES tracking_sessions(id) ON DELETE CASCADE,
    INDEX idx_track_session (session_id),
    INDEX idx_track_object_class (object_class),
    INDEX idx_track_id (tracking_id)
) ENGINE=InnoDB;

-- 5. Detections Table (Frame-level detection events)
CREATE TABLE IF NOT EXISTS detections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    tracking_object_id INT NULL,
    tracking_id INT NOT NULL,
    object_class VARCHAR(50) NOT NULL,
    confidence FLOAT NOT NULL,
    frame_number INT DEFAULT 0,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    bbox_x1 FLOAT NOT NULL,
    bbox_y1 FLOAT NOT NULL,
    bbox_x2 FLOAT NOT NULL,
    bbox_y2 FLOAT NOT NULL,
    snapshot_path VARCHAR(500) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (session_id) REFERENCES tracking_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (tracking_object_id) REFERENCES tracking_objects(id) ON DELETE SET NULL,
    INDEX idx_det_session (session_id),
    INDEX idx_det_class (object_class),
    INDEX idx_det_tracking (tracking_id),
    INDEX idx_det_timestamp (timestamp)
) ENGINE=InnoDB;

-- 6. Reports Table
CREATE TABLE IF NOT EXISTS reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    report_type ENUM('pdf', 'csv') NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    date_range_start DATETIME NULL,
    date_range_end DATETIME NULL,
    filters_applied JSON NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_report_user (user_id)
) ENGINE=InnoDB;

-- 7. Activity Logs Table
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    module VARCHAR(50) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_activity_user (user_id),
    INDEX idx_activity_created (created_at)
) ENGINE=InnoDB;

-- =====================================================================
-- Seed Data: Initial Administrator & Demo Standard User
-- Note: Default password is 'Admin@123' and 'User@123'
-- Passwords will be automatically verified or seeded by the backend.
-- =====================================================================

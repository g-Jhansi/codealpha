import cv2
import numpy as np
import os
from pathlib import Path

def create_sample_video(output_path: str = "sample_data/sample_video.mp4", duration_sec: int = 5, fps: int = 30):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    width, height = 640, 480
    total_frames = duration_sec * fps
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    # Simulate two objects moving across the frame
    for f in range(total_frames):
        frame = np.full((height, width, 3), 245, dtype=np.uint8) # Light background
        
        # Grid lines simulating road / floor
        cv2.line(frame, (0, 360), (width, 360), (200, 200, 200), 2)
        cv2.line(frame, (0, 420), (width, 420), (200, 200, 200), 2)
        
        # Object 1 moving left to right
        x1 = int((f / total_frames) * (width - 100)) + 20
        y1 = 260
        # Draw vehicle-like shape
        cv2.rectangle(frame, (x1, y1), (x1 + 80, y1 + 50), (235, 99, 37), -1) # Blue vehicle
        cv2.circle(frame, (x1 + 20, y1 + 50), 10, (15, 23, 42), -1)
        cv2.circle(frame, (x1 + 60, y1 + 50), 10, (15, 23, 42), -1)
        
        # Object 2 moving right to left
        x2 = int(((total_frames - f) / total_frames) * (width - 60)) + 10
        y2 = 180
        # Draw person-like shape
        cv2.circle(frame, (x2 + 15, y2), 12, (34, 197, 94), -1) # Green head
        cv2.rectangle(frame, (x2 + 8, y2 + 12), (x2 + 22, y2 + 45), (34, 197, 94), -1) # Body
        
        # Timestamp text
        cv2.putText(frame, f"Frame {f+1}/{total_frames} | {f/fps:.1f}s", (20, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (100, 100, 100), 2)
        
        out.write(frame)
        
    out.release()
    print(f"[OK] Sample test video created at: {output_path} ({os.path.getsize(output_path)} bytes)")

if __name__ == "__main__":
    create_sample_video()

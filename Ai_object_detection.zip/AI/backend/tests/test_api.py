import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import uuid

# Set test environment
import os
os.environ["DATABASE_URL"] = "sqlite:///./test_backend.db"
os.environ["SECRET_KEY"] = "testsecret"
os.environ["YOLO_MODEL_NAME"] = "yolov8n.pt"

from app.main import app
from app.database import Base, get_db

# Setup test DB
engine = create_engine(os.environ["DATABASE_URL"], connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base.metadata.create_all(bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

@pytest.fixture(scope="module")
def test_user():
    # Setup
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    
    unique_name = f"testuser_{uuid.uuid4().hex[:6]}"
    unique_email = f"{unique_name}@example.com"
    
    # Register user
    response = client.post(
        "/api/auth/register",
        json={
            "username": unique_name,
            "email": unique_email,
            "password": "Password123!",
            "full_name": "Test User"
        }
    )
    assert response.status_code == 201
    
    # Login user
    login_data = {
        "username": unique_name,
        "password": "Password123!"
    }
    response = client.post("/api/auth/login", json=login_data)
    assert response.status_code == 200
    token = response.json()["access_token"]
    
    yield {"username": unique_name, "token": token}
    
    # Teardown
    Base.metadata.drop_all(bind=engine)

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_login_invalid_credentials():
    login_data = {
        "username": "nonexistent_user",
        "password": "wrongpassword"
    }
    response = client.post("/api/auth/login", json=login_data)
    assert response.status_code == 401

def test_get_dashboard_stats(test_user):
    headers = {"Authorization": f"Bearer {test_user['token']}"}
    response = client.get("/api/dashboard/stats", headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "total_videos" in data
    assert "total_detections" in data

def test_upload_invalid_video(test_user):
    headers = {"Authorization": f"Bearer {test_user['token']}"}
    files = {"file": ("test.txt", b"fake video content", "text/plain")}
    response = client.post("/api/videos/upload", headers=headers, files=files)
    assert response.status_code == 400
    assert "Unsupported file format" in response.json()["detail"]

def test_get_videos_list(test_user):
    headers = {"Authorization": f"Bearer {test_user['token']}"}
    response = client.get("/api/videos/", headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_analytics_summary(test_user):
    headers = {"Authorization": f"Bearer {test_user['token']}"}
    response = client.get("/api/analytics/summary", headers=headers)
    assert response.status_code == 200

def test_settings_get(test_user):
    headers = {"Authorization": f"Bearer {test_user['token']}"}
    response = client.get("/api/settings/", headers=headers)
    assert response.status_code == 200

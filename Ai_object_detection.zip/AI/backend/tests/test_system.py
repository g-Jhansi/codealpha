import os
import sys
import numpy as np
import cv2
from datetime import datetime

# Add root directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from backend.app.config import settings
from backend.app.database import SessionLocal, Base, engine
from backend.app.models.user import User
from backend.app.models.detection import Detection
from backend.app.models.tracking import TrackingSession, TrackingObject
from backend.app.services.ai_engine import ai_engine
from backend.app.services.auth_service import get_password_hash, verify_password, create_access_token
from backend.app.services.report_service import generate_pdf_report, generate_csv_report

def run_tests():
    print("==========================================================")
    print("AI-Based Real-Time Object Detection & Tracking System Tests")
    print("==========================================================")
    
    # 1. Database & Table Creation
    print("\n[Test 1] Initializing Database Schema...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    print("✓ Database connected and tables verified.")

    # 2. Authentication Hashing & JWT Verification
    print("\n[Test 2] Testing Password Hashing and JWT Token issuance...")
    password = "TestPassword@123"
    hashed = get_password_hash(password)
    assert verify_password(password, hashed), "Password verification failed"
    token = create_access_token(data={"sub": "test_operator", "role": "user"})
    assert token and isinstance(token, str), "Token creation failed"
    print("✓ Bcrypt password hashing & JWT tokens operating correctly.")

    # 3. AI Engine Frame Processing & Tracking
    print("\n[Test 3] Testing AI Engine (YOLOv8 + ByteTrack) inference...")
    # Create a synthetic test frame (640x480)
    synthetic_frame = np.zeros((480, 640, 3), dtype=np.uint8)
    cv2.rectangle(synthetic_frame, (100, 100), (300, 350), (200, 200, 200), -1)
    cv2.putText(synthetic_frame, "Test Subject", (120, 200), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)

    annotated, detections, telemetry = ai_engine.process_frame(
        frame=synthetic_frame,
        confidence_threshold=0.25,
        draw_annotations=True,
        show_trajectories=True
    )
    assert annotated.shape == synthetic_frame.shape, "Annotated frame shape mismatch"
    assert "fps" in telemetry and "inference_latency_ms" in telemetry, "Telemetry missing keys"
    print(f"✓ AI Engine inference completed: Latency={telemetry['inference_latency_ms']}ms, FPS={telemetry['fps']}.")

    # 4. Data Insertion & Querying
    print("\n[Test 4] Testing Session and Detection Logging...")
    admin = db.query(User).filter(User.username == "admin").first()
    if not admin:
        admin = User(
            username="admin",
            email="admin@test.com",
            full_name="Admin Test",
            hashed_password=hashed,
            role="admin"
        )
        db.add(admin)
        db.commit()
        db.refresh(admin)

    test_session = TrackingSession(
        user_id=admin.id,
        source_type="live",
        session_name="Automated Test Run",
        start_time=datetime.utcnow()
    )
    db.add(test_session)
    db.commit()
    db.refresh(test_session)

    det = Detection(
        session_id=test_session.id,
        tracking_id=99,
        object_class="person",
        confidence=0.95,
        frame_number=1,
        bbox_x1=100.0,
        bbox_y1=100.0,
        bbox_x2=300.0,
        bbox_y2=350.0
    )
    db.add(det)
    db.commit()
    print("✓ Tracking session and detection record logged to database.")

    # 5. PDF & CSV Report Generation
    print("\n[Test 5] Testing PDF and CSV Report Generators...")
    pdf_report = generate_pdf_report(db, admin.id, "Automated Test PDF Audit")
    assert os.path.exists(pdf_report.file_path), f"PDF file not found at {pdf_report.file_path}"
    assert os.path.getsize(pdf_report.file_path) > 0, "PDF file is empty"
    print(f"✓ PDF report generated successfully ({os.path.getsize(pdf_report.file_path)} bytes).")

    csv_report = generate_csv_report(db, admin.id, "Automated Test CSV Export")
    assert os.path.exists(csv_report.file_path), f"CSV file not found at {csv_report.file_path}"
    assert os.path.getsize(csv_report.file_path) > 0, "CSV file is empty"
    print(f"✓ CSV report generated successfully ({os.path.getsize(csv_report.file_path)} bytes).")

    db.close()
    print("\n==========================================================")
    print("ALL 5 CORE SYSTEM TESTS PASSED SUCCESSFULLY!")
    print("==========================================================")

if __name__ == "__main__":
    run_tests()

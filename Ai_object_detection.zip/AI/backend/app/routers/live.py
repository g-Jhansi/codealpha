import cv2
import base64
import json
import time
import os
import numpy as np
from datetime import datetime
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel

from ..config import settings
from ..database import get_db, SessionLocal
from ..models.user import User
from ..models.tracking import TrackingSession, TrackingObject
from ..models.detection import Detection
from ..services.ai_engine import ai_engine
from ..services.auth_service import get_current_user

router = APIRouter(prefix="/live", tags=["Live Camera"])

class SnapshotRequest(BaseModel):
    image_base64: str
    detections: list
    session_name: str = "Live Webcam Session"

@router.websocket("/ws-stream")
async def websocket_live_stream(websocket: WebSocket):
    """
    High-performance, bidirectional WebSocket endpoint.
    Receives JPEG base64 webcam frames from React client,
    executes YOLOv8 + ByteTrack inference, and returns
    annotated frame + bounding box telemetry.
    """
    await websocket.accept()
    try:
        while True:
            # Receive client message
            raw_data = await websocket.receive_text()
            data = json.loads(raw_data)

            img_b64 = data.get("image")
            if not img_b64:
                continue

            # Strip data URL prefix if present
            if "," in img_b64:
                img_b64 = img_b64.split(",")[1]

            img_bytes = base64.b64decode(img_b64)
            nparr = np.frombuffer(img_bytes, np.uint8)
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

            if frame is None:
                await websocket.send_json({"error": "Failed to decode frame"})
                continue

            conf_thresh = float(data.get("conf", settings.DEFAULT_CONF_THRESHOLD))
            iou_thresh = float(data.get("iou", settings.DEFAULT_IOU_THRESHOLD))
            allowed_classes = data.get("classes", None)

            # Process frame with AI Engine
            annotated_frame, detections, telemetry = ai_engine.process_frame(
                frame=frame,
                confidence_threshold=conf_thresh,
                iou_threshold=iou_thresh,
                allowed_classes=allowed_classes,
                draw_annotations=True,
                show_trajectories=True,
                persist=True
            )

            # Re-encode annotated frame to JPEG base64
            _, buffer = cv2.imencode('.jpg', annotated_frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
            annotated_b64 = base64.b64encode(buffer).decode('utf-8')

            # Send back detections and annotated image
            response_payload = {
                "telemetry": telemetry,
                "detections": detections,
                "annotated_image": f"data:image/jpeg;base64,{annotated_b64}"
            }
            await websocket.send_json(response_payload)

    except WebSocketDisconnect:
        # Client disconnected cleanly
        pass
    except Exception as e:
        try:
            await websocket.send_json({"error": str(e)})
        except Exception:
            pass

@router.post("/snapshot")
def save_live_snapshot(
    req: SnapshotRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Saves an annotated live snapshot and persists detections to database
    so they are immediately searchable in Detection History and Reports.
    """
    img_b64 = req.image_base64
    if "," in img_b64:
        img_b64 = img_b64.split(",")[1]

    img_bytes = base64.b64decode(img_b64)
    filename = f"snap_live_{current_user.id}_{int(time.time())}.jpg"
    filepath = os.path.join(str(settings.SNAPSHOT_DIR), filename)

    with open(filepath, "wb") as f:
        f.write(img_bytes)

    rel_snapshot_path = f"/static/snapshots/{filename}"

    # Create or find live session
    session = TrackingSession(
        user_id=current_user.id,
        source_type="live",
        session_name=req.session_name,
        start_time=datetime.utcnow(),
        total_objects=len(req.detections)
    )
    db.add(session)
    db.commit()
    db.refresh(session)

    # Save detections
    for det in req.detections:
        bbox = det.get("bbox", [0, 0, 100, 100])
        d_record = Detection(
            session_id=session.id,
            tracking_id=det.get("tracking_id", 0),
            object_class=det.get("object_class", "unknown"),
            confidence=det.get("confidence", 0.0),
            frame_number=1,
            timestamp=datetime.utcnow(),
            bbox_x1=float(bbox[0]),
            bbox_y1=float(bbox[1]),
            bbox_x2=float(bbox[2]),
            bbox_y2=float(bbox[3]),
            snapshot_path=rel_snapshot_path
        )
        db.add(d_record)
    
    db.commit()

    return {
        "message": "Snapshot saved to detection history successfully",
        "snapshot_url": rel_snapshot_path,
        "total_detections_logged": len(req.detections)
    }

def generate_server_camera_frames(device_index: int = 0):
    cap = cv2.VideoCapture(device_index)
    while True:
        success, frame = cap.read()
        if not success:
            break
        annotated_frame, _, _ = ai_engine.process_frame(frame)
        ret, buffer = cv2.imencode('.jpg', annotated_frame)
        if not ret:
            continue
        frame_bytes = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    cap.release()

@router.get("/mjpeg-feed")
def mjpeg_video_feed(device_index: int = 0):
    """Optional MJPEG stream for server-side attached cameras."""
    return StreamingResponse(
        generate_server_camera_frames(device_index),
        media_type="multipart/x-mixed-replace; boundary=frame"
    )

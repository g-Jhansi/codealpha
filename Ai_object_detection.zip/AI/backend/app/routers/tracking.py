from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models.user import User
from ..models.tracking import TrackingSession, TrackingObject
from ..schemas.tracking import TrackingSessionResponse, TrackingObjectResponse
from ..services.auth_service import get_current_user

router = APIRouter(prefix="/tracking", tags=["Object Tracking"])

@router.get("/sessions", response_model=List[TrackingSessionResponse])
def get_tracking_sessions(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(TrackingSession)
    if current_user.role != "admin":
        query = query.filter(TrackingSession.user_id == current_user.id)
    return query.order_by(TrackingSession.created_at.desc()).all()

@router.get("/sessions/{session_id}", response_model=TrackingSessionResponse)
def get_tracking_session_details(
    session_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    session = db.query(TrackingSession).filter(TrackingSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Tracking session not found")
    if current_user.role != "admin" and session.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to access this session")
    return session

@router.get("/objects/{object_id}", response_model=TrackingObjectResponse)
def get_tracking_object(
    object_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    obj = db.query(TrackingObject).filter(TrackingObject.id == object_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Tracked object not found")
    return obj

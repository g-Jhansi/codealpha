import math
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc, asc, distinct

from ..database import get_db
from ..models.user import User
from ..models.detection import Detection
from ..models.tracking import TrackingSession
from ..models.video import Video
from ..schemas.detection import DetectionResponse, PaginatedDetections
from ..services.auth_service import get_current_user

router = APIRouter(prefix="/detections", tags=["Detection History"])

@router.get("/", response_model=PaginatedDetections)
def get_detections(
    search: Optional[str] = Query(None, description="Search by object class or tracking ID"),
    object_class: Optional[str] = Query(None, description="Filter by object class"),
    session_id: Optional[int] = Query(None, description="Filter by session ID"),
    min_confidence: Optional[float] = Query(None, description="Filter by minimum confidence (0.0 - 1.0)"),
    start_date: Optional[datetime] = Query(None, description="Filter from start date"),
    end_date: Optional[datetime] = Query(None, description="Filter to end date"),
    sort_by: str = Query("timestamp", description="Column to sort by: timestamp, confidence, object_class, tracking_id"),
    sort_order: str = Query("desc", description="Sort order: asc or desc"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(25, ge=5, le=100, description="Items per page"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Detection)

    # Search filter
    if search:
        search_clean = search.strip().lower()
        if search_clean.isdigit():
            query = query.filter(
                (Detection.tracking_id == int(search_clean)) |
                (Detection.object_class.ilike(f"%{search_clean}%"))
            )
        else:
            query = query.filter(Detection.object_class.ilike(f"%{search_clean}%"))

    # Direct Filters
    if object_class:
        query = query.filter(Detection.object_class.ilike(object_class.strip()))
    if session_id:
        query = query.filter(Detection.session_id == session_id)
    if min_confidence is not None:
        query = query.filter(Detection.confidence >= min_confidence)
    if start_date:
        query = query.filter(Detection.timestamp >= start_date)
    if end_date:
        query = query.filter(Detection.timestamp <= end_date)

    # Total Count
    total = query.count()

    # Sorting
    sort_column = Detection.timestamp
    if sort_by == "confidence":
        sort_column = Detection.confidence
    elif sort_by == "object_class":
        sort_column = Detection.object_class
    elif sort_by == "tracking_id":
        sort_column = Detection.tracking_id

    if sort_order.lower() == "asc":
        query = query.order_by(asc(sort_column))
    else:
        query = query.order_by(desc(sort_column))

    # Pagination
    offset = (page - 1) * page_size
    detections = query.offset(offset).limit(page_size).all()
    total_pages = math.ceil(total / page_size) if total > 0 else 1

    # Attach video name if available
    items = []
    for d in detections:
        video_name = None
        if d.session and d.session.video:
            video_name = d.session.video.original_name
        elif d.session:
            video_name = d.session.session_name

        items.append(
            DetectionResponse(
                id=d.id,
                session_id=d.session_id,
                tracking_object_id=d.tracking_object_id,
                tracking_id=d.tracking_id,
                object_class=d.object_class,
                confidence=d.confidence,
                frame_number=d.frame_number,
                timestamp=d.timestamp,
                created_at=d.created_at,
                bbox_x1=d.bbox_x1,
                bbox_y1=d.bbox_y1,
                bbox_x2=d.bbox_x2,
                bbox_y2=d.bbox_y2,
                snapshot_path=d.snapshot_path,
                video_name=video_name
            )
        )

    return PaginatedDetections(
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        items=items
    )

@router.get("/classes", response_model=List[str])
def get_distinct_detected_classes(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Returns list of all unique object classes currently in the database."""
    classes = db.query(distinct(Detection.object_class)).all()
    return sorted([c[0] for c in classes if c[0]])

import os
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..models.user import User
from ..models.report import Report
from ..schemas.report import ReportGenerateRequest, ReportResponse
from ..services.auth_service import get_current_user
from ..services.report_service import generate_pdf_report, generate_csv_report

router = APIRouter(prefix="/reports", tags=["Reports & Auditing"])

@router.post("/generate", response_model=ReportResponse, status_code=status.HTTP_201_CREATED)
def generate_report(
    req: ReportGenerateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if req.report_type.lower() == "pdf":
        report = generate_pdf_report(
            db=db,
            user_id=current_user.id,
            title=req.title,
            start_date=req.start_date,
            end_date=req.end_date,
            object_classes=req.object_classes,
            min_confidence=req.min_confidence
        )
    elif req.report_type.lower() == "csv":
        report = generate_csv_report(
            db=db,
            user_id=current_user.id,
            title=req.title,
            start_date=req.start_date,
            end_date=req.end_date,
            object_classes=req.object_classes,
            min_confidence=req.min_confidence
        )
    else:
        raise HTTPException(status_code=400, detail="Invalid report type. Supported types: 'pdf', 'csv'")

    resp = ReportResponse.from_orm(report)
    resp.download_url = f"/api/reports/{report.id}/download"
    return resp

@router.get("/", response_model=List[ReportResponse])
def list_reports(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Report)
    if current_user.role != "admin":
        query = query.filter(Report.user_id == current_user.id)
    reports = query.order_by(Report.created_at.desc()).all()

    results = []
    for r in reports:
        item = ReportResponse.from_orm(r)
        item.download_url = f"/api/reports/{r.id}/download"
        results.append(item)
    return results

@router.get("/{report_id}/download")
def download_report(
    report_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if current_user.role != "admin" and report.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to download this report")

    if not os.path.exists(report.file_path):
        raise HTTPException(status_code=404, detail="Report file not found on disk")

    media_type = "application/pdf" if report.report_type == "pdf" else "text/csv"
    return FileResponse(
        report.file_path,
        media_type=media_type,
        filename=os.path.basename(report.file_path)
    )

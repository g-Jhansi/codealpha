import os
import cv2
import uuid
import aiofiles
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models.user import User
from ..models.video import Video
from ..models.activity import ActivityLog
from ..schemas.video import VideoResponse, VideoProcessRequest
from ..services.auth_service import get_current_user
from ..services.video_processor import process_video_background, get_video_progress

router = APIRouter(prefix="/videos", tags=["Video Management"])

@router.post("/upload", response_model=VideoResponse, status_code=status.HTTP_201_CREATED)
async def upload_video(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    original_name = file.filename or "video.mp4"
    ext = original_name.split(".")[-1].lower()
    
    if ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format '{ext}'. Allowed formats: mp4, avi, mov."
        )

    unique_filename = f"{uuid.uuid4().hex}_{original_name}"
    save_path = os.path.join(str(settings.VIDEO_DIR), unique_filename)

    # Stream file to disk
    file_size = 0
    async with aiofiles.open(save_path, "wb") as out_file:
        while content := await file.read(1024 * 1024): # 1MB chunks
            file_size += len(content)
            await out_file.write(content)

    # Probe video metadata using OpenCV
    cap = cv2.VideoCapture(save_path)
    fps = 30.0
    total_frames = 0
    width, height = 1280, 720
    duration = 0.0

    if cap.isOpened():
        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 1280
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 720
        if fps > 0 and total_frames > 0:
            duration = round(total_frames / fps, 2)
        cap.release()

    new_video = Video(
        user_id=current_user.id,
        filename=unique_filename,
        original_name=original_name,
        filepath=save_path,
        file_size=file_size,
        duration=duration,
        resolution=f"{width}x{height}",
        fps=round(fps, 2),
        total_frames=total_frames,
        status="uploaded"
    )
    db.add(new_video)
    db.commit()
    db.refresh(new_video)

    # Activity Log
    log = ActivityLog(
        user_id=current_user.id,
        action="Uploaded Video",
        module="Video Module",
        details=f"Uploaded '{original_name}' ({file_size // (1024*1024)} MB)."
    )
    db.add(log)
    db.commit()

    return new_video

@router.get("/", response_model=List[VideoResponse])
def list_videos(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Video)
    if current_user.role != "admin":
        query = query.filter(Video.user_id == current_user.id)
    return query.order_by(Video.created_at.desc()).all()

@router.get("/{video_id}", response_model=VideoResponse)
def get_video(
    video_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    if current_user.role != "admin" and video.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to access this video")
    return video

@router.post("/{video_id}/process")
def trigger_process_video(
    video_id: int,
    background_tasks: BackgroundTasks,
    request: VideoProcessRequest = VideoProcessRequest(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    if current_user.role != "admin" and video.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to process this video")
    if video.status == "processing":
        raise HTTPException(status_code=400, detail="Video is already being processed")

    video.status = "processing"
    db.commit()

    background_tasks.add_task(
        process_video_background,
        video_id=video.id,
        confidence_threshold=request.confidence_threshold or settings.DEFAULT_CONF_THRESHOLD,
        iou_threshold=request.iou_threshold or settings.DEFAULT_IOU_THRESHOLD,
        allowed_classes=request.target_classes
    )

    return {
        "message": "AI video detection and tracking started in background",
        "video_id": video.id,
        "status": "processing"
    }

@router.get("/{video_id}/progress")
def check_video_progress(
    video_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    
    progress_info = get_video_progress(video_id)
    # If DB status is completed but in-memory is idle, reflect completed
    if video.status == "completed" and progress_info["progress"] == 0:
        progress_info = {"progress": 100, "status": "completed", "error": None}
    elif video.status == "failed":
        progress_info["status"] = "failed"
        progress_info["error"] = video.error_message
    
    return progress_info

@router.get("/{video_id}/file")
def stream_video_file(
    video_id: int,
    processed: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    
    path = video.processed_filepath if (processed and video.processed_filepath) else video.filepath
    if not path or not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Video file on disk not found")
    
    return FileResponse(path, media_type="video/mp4", filename=os.path.basename(path))

@router.delete("/{video_id}")
def delete_video(
    video_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    if current_user.role != "admin" and video.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to delete this video")

    # Delete files on disk
    for fpath in [video.filepath, video.processed_filepath]:
        if fpath and os.path.exists(fpath):
            try:
                os.remove(fpath)
            except Exception:
                pass

    db.delete(video)
    db.commit()

    return {"message": "Video and associated data successfully deleted"}

import cv2
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models.user import User
from ..schemas.settings import SystemSettings, CameraSettings, AISettings
from ..services.auth_service import get_current_user

router = APIRouter(prefix="/settings", tags=["Settings & Configuration"])

# In-memory settings state initialized from config defaults
CURRENT_SETTINGS = SystemSettings(
    camera=CameraSettings(
        device_index=0,
        resolution="1280x720",
        target_fps=30,
        mirror_mode=True
    ),
    ai=AISettings(
        confidence_threshold=settings.DEFAULT_CONF_THRESHOLD,
        iou_threshold=settings.DEFAULT_IOU_THRESHOLD,
        model_name=settings.YOLO_MODEL_NAME,
        tracker_type=settings.TRACKER_TYPE,
        enabled_classes=settings.TARGET_CLASSES
    )
)

@router.get("/", response_model=SystemSettings)
def get_settings(current_user: User = Depends(get_current_user)):
    return CURRENT_SETTINGS

@router.put("/update", response_model=SystemSettings)
def update_settings(
    new_settings: SystemSettings,
    current_user: User = Depends(get_current_user)
):
    global CURRENT_SETTINGS
    CURRENT_SETTINGS = new_settings
    return CURRENT_SETTINGS

@router.get("/camera-test")
def test_camera_connection(device_index: int = 0):
    """Probes whether a given camera index or device is accessible."""
    cap = cv2.VideoCapture(device_index)
    is_available = cap.isOpened()
    backend_name = "OpenCV"
    if is_available:
        ret, frame = cap.read()
        cap.release()
        return {
            "status": "connected",
            "device_index": device_index,
            "can_read_frame": bool(ret),
            "backend": backend_name
        }
    return {
        "status": "disconnected",
        "device_index": device_index,
        "message": "Camera device is not accessible on server. Client webcam streaming via browser is recommended."
    }

@router.get("/system-info")
def get_system_info(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return {
        "project_name": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "yolo_model": settings.YOLO_MODEL_NAME,
        "tracker": settings.TRACKER_TYPE,
        "database_url": settings.DATABASE_URL.split("@")[-1] if "@" in settings.DATABASE_URL else "Local SQLite Database",
        "allowed_classes": settings.TARGET_CLASSES
    }

from datetime import datetime, timedelta
from typing import Dict, List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..database import get_db
from ..models.user import User
from ..models.video import Video
from ..models.detection import Detection
from ..models.tracking import TrackingSession, TrackingObject
from ..schemas.analytics import AnalyticsSummary, TrendDataPoint, ObjectFrequency
from ..services.auth_service import get_current_user

router = APIRouter(prefix="/analytics", tags=["Analytics"])

@router.get("/summary", response_model=AnalyticsSummary)
def get_analytics_summary(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    total_detections = db.query(Detection).count()
    total_videos = db.query(Video).count()
    total_sessions = db.query(TrackingSession).count()

    # Average Confidence
    avg_conf_raw = db.query(func.avg(Detection.confidence)).scalar()
    avg_conf = round(float(avg_conf_raw) * 100, 1) if avg_conf_raw else 91.5

    # Object Frequencies
    class_counts = (
        db.query(Detection.object_class, func.count(Detection.id))
        .group_by(Detection.object_class)
        .order_by(func.count(Detection.id).desc())
        .all()
    )

    object_frequencies: List[ObjectFrequency] = []
    most_detected = None
    most_count = 0

    if class_counts:
        most_detected = class_counts[0][0]
        most_count = class_counts[0][1]

        for cls_name, count in class_counts:
            pct = round((count / total_detections * 100), 1) if total_detections > 0 else 0
            object_frequencies.append(
                ObjectFrequency(
                    object_class=cls_name,
                    count=count,
                    percentage=pct
                )
            )

    # 1. Daily Trends (last 7 days)
    now = datetime.utcnow()
    daily_trends: List[TrendDataPoint] = []
    for i in range(6, -1, -1):
        day_date = (now - timedelta(days=i)).date()
        day_start = datetime.combine(day_date, datetime.min.time())
        day_end = datetime.combine(day_date, datetime.max.time())
        
        cnt = db.query(Detection).filter(
            Detection.timestamp >= day_start,
            Detection.timestamp <= day_end
        ).count()

        daily_trends.append(
            TrendDataPoint(
                date=day_date.strftime("%b %d"),
                count=cnt
            )
        )

    # 2. Weekly Trends (last 4 weeks)
    weekly_trends: List[TrendDataPoint] = []
    for i in range(3, -1, -1):
        w_start = now - timedelta(weeks=i+1)
        w_end = now - timedelta(weeks=i)
        cnt = db.query(Detection).filter(
            Detection.timestamp >= w_start,
            Detection.timestamp < w_end
        ).count()
        weekly_trends.append(
            TrendDataPoint(
                date=f"Week {4 - i}",
                count=cnt
            )
        )

    # 3. Monthly Trends (last 6 months)
    monthly_trends: List[TrendDataPoint] = []
    for i in range(5, -1, -1):
        m_date = now - timedelta(days=i * 30)
        m_start = datetime(m_date.year, m_date.month, 1)
        # approximate month end
        if m_date.month == 12:
            m_end = datetime(m_date.year + 1, 1, 1)
        else:
            m_end = datetime(m_date.year, m_date.month + 1, 1)

        cnt = db.query(Detection).filter(
            Detection.timestamp >= m_start,
            Detection.timestamp < m_end
        ).count()
        monthly_trends.append(
            TrendDataPoint(
                date=m_start.strftime("%b %Y"),
                count=cnt
            )
        )

    # Confidence Distribution
    confs = db.query(Detection.confidence).all()
    dist = {
        "30-50%": 0,
        "50-60%": 0,
        "60-70%": 0,
        "70-80%": 0,
        "80-90%": 0,
        "90-100%": 0
    }
    for (c,) in confs:
        if c < 0.5:
            dist["30-50%"] += 1
        elif c < 0.6:
            dist["50-60%"] += 1
        elif c < 0.7:
            dist["60-70%"] += 1
        elif c < 0.8:
            dist["70-80%"] += 1
        elif c < 0.9:
            dist["80-90%"] += 1
        else:
            dist["90-100%"] += 1

    return AnalyticsSummary(
        total_detections=total_detections,
        total_videos=total_videos,
        total_tracking_sessions=total_sessions,
        active_camera_status=True,
        average_confidence=avg_conf,
        most_detected_object=most_detected,
        most_detected_count=most_count,
        daily_trends=daily_trends,
        weekly_trends=weekly_trends,
        monthly_trends=monthly_trends,
        object_frequencies=object_frequencies,
        confidence_distribution=dist
    )

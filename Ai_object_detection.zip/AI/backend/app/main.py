import os
from datetime import datetime, timedelta
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import settings
from .database import engine, Base, SessionLocal
from .models.user import User
from .models.tracking import TrackingSession, TrackingObject
from .models.detection import Detection
from .models.activity import ActivityLog
from .services.auth_service import get_password_hash

# Routers
from .routers import auth, dashboard, videos, live, detections, tracking, analytics, reports, settings as settings_router

# Initialize FastAPI application
app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Enterprise-grade AI-Based Real-Time Object Detection and Multi-Object Tracking System using YOLOv8, ByteTrack, and FastAPI.",
    version=settings.VERSION,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Static Directories for Video streaming, Snapshots, and Reports
app.mount("/static/snapshots", StaticFiles(directory=str(settings.SNAPSHOT_DIR)), name="snapshots")
app.mount("/static/videos", StaticFiles(directory=str(settings.PROCESSED_DIR)), name="videos")
app.mount("/static/reports", StaticFiles(directory=str(settings.REPORT_DIR)), name="reports")

# Include API Routers
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(dashboard.router, prefix=settings.API_V1_STR)
app.include_router(videos.router, prefix=settings.API_V1_STR)
app.include_router(live.router, prefix=settings.API_V1_STR)
app.include_router(detections.router, prefix=settings.API_V1_STR)
app.include_router(tracking.router, prefix=settings.API_V1_STR)
app.include_router(analytics.router, prefix=settings.API_V1_STR)
app.include_router(reports.router, prefix=settings.API_V1_STR)
app.include_router(settings_router.router, prefix=settings.API_V1_STR)

@app.on_event("startup")
def on_startup():
    """Create tables and seed initial admin, demo users, and baseline mock data if empty."""
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    try:
        # 1. Seed Admin User
        admin_user = db.query(User).filter(User.username == "admin").first()
        if not admin_user:
            admin_user = User(
                username="admin",
                email="admin@aitracking.system",
                full_name="System Administrator",
                hashed_password=get_password_hash("Admin@123"),
                role="admin",
                is_active=True
            )
            db.add(admin_user)
            db.commit()
            db.refresh(admin_user)
            print("[Startup] Seeded default administrator: admin / Admin@123")

        # 2. Seed Standard User
        demo_user = db.query(User).filter(User.username == "user").first()
        if not demo_user:
            demo_user = User(
                username="user",
                email="user@aitracking.system",
                full_name="Standard Operator",
                hashed_password=get_password_hash("User@123"),
                role="user",
                is_active=True
            )
            db.add(demo_user)
            db.commit()
            db.refresh(demo_user)
            print("[Startup] Seeded default standard user: user / User@123")

        # 3. Seed baseline detections if database is completely empty
        if db.query(Detection).count() == 0:
            print("[Startup] Seeding initial baseline telemetry data for dashboard charts...")
            now = datetime.utcnow()
            
            session = TrackingSession(
                user_id=admin_user.id,
                source_type="live",
                session_name="Baseline System Calibration Session",
                start_time=now - timedelta(days=2),
                end_time=now,
                total_objects=6
            )
            db.add(session)
            db.commit()
            db.refresh(session)

            sample_objects = [
                ("person", 1, 0.94, 18.5, [(320, 240), (325, 245), (330, 250), (340, 255)]),
                ("car", 2, 0.91, 24.2, [(100, 400), (120, 400), (150, 400), (190, 400)]),
                ("laptop", 3, 0.88, 120.0, [(450, 300), (450, 300), (450, 301)]),
                ("dog", 4, 0.85, 14.8, [(500, 420), (510, 415), (525, 410)]),
                ("bottle", 5, 0.92, 95.0, [(600, 280), (600, 280)]),
                ("person", 6, 0.89, 45.2, [(200, 250), (210, 255), (225, 260)])
            ]

            for cls_name, tid, conf, dur, traj in sample_objects:
                t_obj = TrackingObject(
                    session_id=session.id,
                    tracking_id=tid,
                    object_class=cls_name,
                    first_detected_at=now - timedelta(hours=tid * 2),
                    last_detected_at=now - timedelta(hours=tid * 2) + timedelta(seconds=dur),
                    duration_seconds=dur,
                    trajectory_data=traj,
                    avg_confidence=conf
                )
                db.add(t_obj)
                db.commit()
                db.refresh(t_obj)

                # Add sample detections distributed over recent days
                for f_num in range(1, 6):
                    det_time = now - timedelta(days=(f_num % 3), hours=(tid * 2), minutes=(f_num * 5))
                    det = Detection(
                        session_id=session.id,
                        tracking_object_id=t_obj.id,
                        tracking_id=tid,
                        object_class=cls_name,
                        confidence=conf - (0.01 * f_num),
                        frame_number=f_num * 15,
                        timestamp=det_time,
                        bbox_x1=traj[0][0] - 30,
                        bbox_y1=traj[0][1] - 40,
                        bbox_x2=traj[0][0] + 30,
                        bbox_y2=traj[0][1] + 40
                    )
                    db.add(det)
            
            db.commit()

            # Seed activity log
            db.add(ActivityLog(
                user_id=admin_user.id,
                action="System Initialized",
                module="Core",
                details="Database tables generated and default seed models prepared."
            ))
            db.commit()
            print("[Startup] Baseline telemetry data successfully initialized.")

    except Exception as e:
        db.rollback()
        print(f"[Startup Error] {e}")
    finally:
        db.close()

@app.get("/")
def root():
    return {
        "project": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "online",
        "docs": "/docs",
        "api_v1": settings.API_V1_STR
    }

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "database": "connected"
    }

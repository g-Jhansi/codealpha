import os
from pathlib import Path
from pydantic_settings import BaseSettings

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    PROJECT_NAME: str = "AI-Based Real-Time Object Detection and Tracking System"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api"
    
    # Security / JWT
    SECRET_KEY: str = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 # 24 hours
    
    # Database (MySQL support with automatic SQLite fallback)
    DATABASE_URL: str = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR}/data/ai_tracking.db")
    
    # Storage Paths
    BASE_DIR: Path = BASE_DIR
    DATA_DIR: Path = BASE_DIR / "data"
    UPLOAD_DIR: Path = BASE_DIR / "uploads"
    VIDEO_DIR: Path = BASE_DIR / "uploads" / "videos"
    PROCESSED_DIR: Path = BASE_DIR / "uploads" / "processed"
    SNAPSHOT_DIR: Path = BASE_DIR / "uploads" / "snapshots"
    REPORT_DIR: Path = BASE_DIR / "uploads" / "reports"
    
    # AI Model & Tracker Defaults
    YOLO_MODEL_NAME: str = "yolov8n.pt"
    DEFAULT_CONF_THRESHOLD: float = 0.35
    DEFAULT_IOU_THRESHOLD: float = 0.45
    TRACKER_TYPE: str = "bytetrack.yaml"
    
    # Target Classes specified in Gemini.md & PRD
    # Mapping to standard COCO labels
    TARGET_CLASSES: list = [
        "person", "car", "bicycle", "motorcycle", "bus", "truck",
        "dog", "cat", "laptop", "cell phone", "chair", "bottle"
    ]
    
    ALLOWED_EXTENSIONS: set = {"mp4", "avi", "mov"}
    MAX_FILE_SIZE_MB: int = 200

    class Config:
        env_file = ".env"
        extra = "allow"

settings = Settings()

# Ensure directories exist
for path in [settings.DATA_DIR, settings.UPLOAD_DIR, settings.VIDEO_DIR, settings.PROCESSED_DIR, settings.SNAPSHOT_DIR, settings.REPORT_DIR]:
    path.mkdir(parents=True, exist_ok=True)

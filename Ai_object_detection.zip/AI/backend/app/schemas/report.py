from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel

class ReportGenerateRequest(BaseModel):
    title: str = "Object Detection & Tracking Audit Report"
    report_type: str = "pdf" # 'pdf' or 'csv'
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    object_classes: Optional[list[str]] = None
    min_confidence: Optional[float] = None

class ReportResponse(BaseModel):
    id: int
    user_id: int
    title: str
    report_type: str
    file_path: str
    date_range_start: Optional[datetime] = None
    date_range_end: Optional[datetime] = None
    filters_applied: Optional[dict[str, Any]] = None
    created_at: datetime
    download_url: Optional[str] = None

    class Config:
        from_attributes = True

from typing import Any, Optional
from pydantic import BaseModel

class TrendDataPoint(BaseModel):
    date: str
    count: int

class ObjectFrequency(BaseModel):
    object_class: str
    count: int
    percentage: float

class AnalyticsSummary(BaseModel):
    total_detections: int
    total_videos: int
    total_tracking_sessions: int
    active_camera_status: bool
    average_confidence: float
    most_detected_object: Optional[str] = None
    most_detected_count: int = 0
    daily_trends: list[TrendDataPoint]
    weekly_trends: list[TrendDataPoint]
    monthly_trends: list[TrendDataPoint]
    object_frequencies: list[ObjectFrequency]
    confidence_distribution: dict[str, int] # e.g. {"50-60%": 12, "60-70%": 45, ...}

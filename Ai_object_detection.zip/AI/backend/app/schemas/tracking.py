from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel

class TrackingObjectResponse(BaseModel):
    id: int
    session_id: int
    tracking_id: int
    object_class: str
    first_detected_at: datetime
    last_detected_at: datetime
    duration_seconds: float
    trajectory_data: Optional[list[Any]] = None
    avg_confidence: float

    class Config:
        from_attributes = True

class TrackingSessionResponse(BaseModel):
    id: int
    user_id: int
    source_type: str
    video_id: Optional[int] = None
    session_name: str
    start_time: datetime
    end_time: Optional[datetime] = None
    total_objects: int
    created_at: datetime
    tracking_objects: Optional[list[TrackingObjectResponse]] = None

    class Config:
        from_attributes = True

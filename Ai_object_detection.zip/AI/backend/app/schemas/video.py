from datetime import datetime
from typing import Optional
from pydantic import BaseModel

class VideoBase(BaseModel):
    original_name: str

class VideoResponse(VideoBase):
    id: int
    user_id: int
    filename: str
    file_size: int
    duration: float
    resolution: str
    fps: float
    total_frames: int
    status: str
    processed_filepath: Optional[str] = None
    error_message: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class VideoProcessRequest(BaseModel):
    confidence_threshold: Optional[float] = 0.35
    iou_threshold: Optional[float] = 0.45
    target_classes: Optional[list[str]] = None

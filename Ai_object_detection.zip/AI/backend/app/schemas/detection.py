from datetime import datetime
from typing import Optional
from pydantic import BaseModel

class DetectionBase(BaseModel):
    tracking_id: int
    object_class: str
    confidence: float
    frame_number: int
    bbox_x1: float
    bbox_y1: float
    bbox_x2: float
    bbox_y2: float
    snapshot_path: Optional[str] = None

class DetectionCreate(DetectionBase):
    session_id: int
    tracking_object_id: Optional[int] = None

class DetectionResponse(DetectionBase):
    id: int
    session_id: int
    tracking_object_id: Optional[int] = None
    timestamp: datetime
    created_at: datetime
    video_name: Optional[str] = None

    class Config:
        from_attributes = True

class DetectionFilterParams(BaseModel):
    search: Optional[str] = None
    object_class: Optional[str] = None
    session_id: Optional[int] = None
    tracking_id: Optional[int] = None
    min_confidence: Optional[float] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    page: int = 1
    page_size: int = 25
    sort_by: str = "timestamp"
    sort_order: str = "desc"

class PaginatedDetections(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    items: list[DetectionResponse]

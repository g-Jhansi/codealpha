from typing import Optional
from pydantic import BaseModel

class CameraSettings(BaseModel):
    device_index: int = 0
    rtsp_url: Optional[str] = None
    resolution: str = "1280x720"
    target_fps: int = 30
    mirror_mode: bool = True

class AISettings(BaseModel):
    confidence_threshold: float = 0.35
    iou_threshold: float = 0.45
    model_name: str = "yolov8n.pt"
    tracker_type: str = "bytetrack.yaml"
    enabled_classes: list[str] = [
        "person", "car", "bicycle", "motorcycle", "bus", "truck",
        "dog", "cat", "laptop", "cell phone", "chair", "bottle"
    ]

class SystemSettings(BaseModel):
    camera: CameraSettings = CameraSettings()
    ai: AISettings = AISettings()

from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, BigInteger, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from ..database import Base

class Video(Base):
    __tablename__ = "videos"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    filename = Column(String(255), nullable=False)
    original_name = Column(String(255), nullable=False)
    filepath = Column(String(500), nullable=False)
    file_size = Column(BigInteger, default=0, nullable=False)
    duration = Column(Float, default=0.0)
    resolution = Column(String(20), default="unknown")
    fps = Column(Float, default=0.0)
    total_frames = Column(Integer, default=0)
    status = Column(String(20), default="uploaded", nullable=False) # 'uploaded', 'processing', 'completed', 'failed'
    processed_filepath = Column(String(500), nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    owner = relationship("User", back_populates="videos")
    tracking_sessions = relationship("TrackingSession", back_populates="video", cascade="all, delete-orphan")

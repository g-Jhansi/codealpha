from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from ..database import Base

class Detection(Base):
    __tablename__ = "detections"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("tracking_sessions.id", ondelete="CASCADE"), nullable=False)
    tracking_object_id = Column(Integer, ForeignKey("tracking_objects.id", ondelete="SET NULL"), nullable=True)
    tracking_id = Column(Integer, index=True, nullable=False)
    object_class = Column(String(50), index=True, nullable=False)
    confidence = Column(Float, nullable=False)
    frame_number = Column(Integer, default=0)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True, nullable=False)
    
    # Bounding Box Coordinates (normalized or absolute pixels)
    bbox_x1 = Column(Float, nullable=False)
    bbox_y1 = Column(Float, nullable=False)
    bbox_x2 = Column(Float, nullable=False)
    bbox_y2 = Column(Float, nullable=False)
    
    snapshot_path = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    session = relationship("TrackingSession", back_populates="detections")
    tracking_object = relationship("TrackingObject", back_populates="detections")

from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from ..database import Base

class TrackingSession(Base):
    __tablename__ = "tracking_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    source_type = Column(String(20), nullable=False) # 'live' or 'video'
    video_id = Column(Integer, ForeignKey("videos.id", ondelete="SET NULL"), nullable=True)
    session_name = Column(String(100), nullable=False)
    start_time = Column(DateTime, default=datetime.utcnow, nullable=False)
    end_time = Column(DateTime, nullable=True)
    total_objects = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="tracking_sessions")
    video = relationship("Video", back_populates="tracking_sessions")
    tracking_objects = relationship("TrackingObject", back_populates="session", cascade="all, delete-orphan")
    detections = relationship("Detection", back_populates="session", cascade="all, delete-orphan")


class TrackingObject(Base):
    __tablename__ = "tracking_objects"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("tracking_sessions.id", ondelete="CASCADE"), nullable=False)
    tracking_id = Column(Integer, index=True, nullable=False) # assigned by ByteTrack
    object_class = Column(String(50), index=True, nullable=False)
    first_detected_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_detected_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    duration_seconds = Column(Float, default=0.0)
    trajectory_data = Column(JSON, nullable=True) # list of [x_center, y_center, timestamp_offset]
    avg_confidence = Column(Float, default=0.0)

    session = relationship("TrackingSession", back_populates="tracking_objects")
    detections = relationship("Detection", back_populates="tracking_object")

import time
import cv2
import numpy as np
from typing import Optional, Tuple, List, Dict, Any
from collections import deque
from ultralytics import YOLO

from ..config import settings

# Class color mapping for consistent, aesthetically pleasing visualization
# Primary blue: #2563EB -> BGR (235, 99, 37)
# Success green: #22C55E -> BGR (94, 197, 34)
# Warning amber: #F59E0B -> BGR (11, 158, 245)
# Danger red: #EF4444 -> BGR (68, 68, 239)
CLASS_COLORS: Dict[str, Tuple[int, int, int]] = {
    "person": (235, 99, 37),      # #2563EB Blue
    "car": (94, 197, 34),         # #22C55E Green
    "bicycle": (11, 158, 245),    # #F59E0B Amber
    "motorcycle": (245, 158, 11), # Orange
    "bus": (200, 70, 240),        # Purple
    "truck": (240, 160, 60),      # Cyan
    "dog": (180, 105, 255),       # Pink
    "cat": (255, 140, 0),         # Deep Orange
    "laptop": (255, 215, 0),      # Gold
    "cell phone": (0, 215, 255),  # Yellow
    "chair": (144, 238, 144),     # Light Green
    "bottle": (135, 206, 235),    # Sky Blue
}

def get_class_color(class_name: str) -> Tuple[int, int, int]:
    if class_name in CLASS_COLORS:
        return CLASS_COLORS[class_name]
    # Deterministic hash color for any other COCO class
    h = hash(class_name)
    return ((h & 0xFF), ((h >> 8) & 0xFF), ((h >> 16) & 0xFF))

class AIEngine:
    def __init__(self, model_name: str = settings.YOLO_MODEL_NAME):
        self.model_name = model_name
        print(f"[AI Engine] Loading YOLOv8 model: {model_name}...")
        self.model = YOLO(model_name)
        print("[AI Engine] Model loaded successfully.")
        
        # In-memory trajectory cache: {tracking_id: deque([(cx, cy), ...], maxlen=30)}
        self.trajectories: Dict[int, deque] = {}
        self.last_seen_times: Dict[int, float] = {}
        self.max_trajectory_length = 30
        self.trajectory_expiry_seconds = 10.0 # Clean up if not seen for 10s

    def clean_stale_trajectories(self):
        now = time.time()
        stale_ids = [
            tid for tid, last_seen in self.last_seen_times.items()
            if now - last_seen > self.trajectory_expiry_seconds
        ]
        for tid in stale_ids:
            self.trajectories.pop(tid, None)
            self.last_seen_times.pop(tid, None)

    def process_frame(
        self,
        frame: np.ndarray,
        confidence_threshold: float = settings.DEFAULT_CONF_THRESHOLD,
        iou_threshold: float = settings.DEFAULT_IOU_THRESHOLD,
        allowed_classes: Optional[List[str]] = None,
        draw_annotations: bool = True,
        show_trajectories: bool = True,
        persist: bool = True
    ) -> Tuple[np.ndarray, List[Dict[str, Any]], Dict[str, Any]]:
        """
        Runs YOLOv8 object detection and ByteTrack tracking on a single frame.
        Returns:
            - annotated_frame (np.ndarray)
            - detections list (dictionaries with tracking_id, class, conf, bbox, trajectory)
            - telemetry metadata (fps, inference_latency_ms, total_objects)
        """
        start_time = time.time()
        self.clean_stale_trajectories()

        height, width = frame.shape[:2]
        
        # Run tracking using ByteTrack
        results = self.model.track(
            source=frame,
            persist=persist,
            tracker=settings.TRACKER_TYPE,
            conf=confidence_threshold,
            iou=iou_threshold,
            verbose=False
        )

        detections = []
        annotated_frame = frame.copy() if draw_annotations else frame
        now = time.time()

        if results and len(results) > 0:
            result = results[0]
            boxes = result.boxes
            
            if boxes is not None and len(boxes) > 0:
                for idx, box in enumerate(boxes):
                    cls_id = int(box.cls[0])
                    class_name = self.model.names[cls_id]
                    
                    # Filter by allowed classes if specified
                    if allowed_classes is not None and class_name not in allowed_classes:
                        continue
                    
                    conf = float(box.conf[0])
                    xyxy = box.xyxy[0].cpu().numpy().tolist()
                    x1, y1, x2, y2 = [int(v) for v in xyxy]

                    # Bounding Box Center
                    cx = int((x1 + x2) / 2)
                    cy = int((y1 + y2) / 2)

                    # Tracking ID from ByteTrack
                    if box.id is not None:
                        track_id = int(box.id[0])
                    else:
                        # Fallback pseudo-ID if tracking is warming up
                        track_id = 1000 + idx

                    # Update Trajectory History
                    if track_id not in self.trajectories:
                        self.trajectories[track_id] = deque(maxlen=self.max_trajectory_length)
                    self.trajectories[track_id].append((cx, cy))
                    self.last_seen_times[track_id] = now
                    
                    traj_points = list(self.trajectories[track_id])

                    det_dict = {
                        "tracking_id": track_id,
                        "object_class": class_name,
                        "confidence": round(conf, 4),
                        "bbox": [x1, y1, x2, y2],
                        "center": [cx, cy],
                        "trajectory": traj_points
                    }
                    detections.append(det_dict)

                    if draw_annotations:
                        color = get_class_color(class_name)
                        
                        # 1. Draw Trajectory Trail
                        if show_trajectories and len(traj_points) > 1:
                            for i in range(1, len(traj_points)):
                                thickness = int(np.sqrt(self.max_trajectory_length / float(i + 1)) * 2)
                                cv2.line(annotated_frame, traj_points[i - 1], traj_points[i], color, max(1, thickness))

                        # 2. Draw Sleek Bounding Box with Corner Accents
                        cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), color, 2)
                        corner_len = min(20, (x2 - x1) // 4, (y2 - y1) // 4)
                        if corner_len > 4:
                            accent_thickness = 3
                            # Top-left
                            cv2.line(annotated_frame, (x1, y1), (x1 + corner_len, y1), color, accent_thickness)
                            cv2.line(annotated_frame, (x1, y1), (x1, y1 + corner_len), color, accent_thickness)
                            # Top-right
                            cv2.line(annotated_frame, (x2, y1), (x2 - corner_len, y1), color, accent_thickness)
                            cv2.line(annotated_frame, (x2, y1), (x2, y1 + corner_len), color, accent_thickness)
                            # Bottom-left
                            cv2.line(annotated_frame, (x1, y2), (x1 + corner_len, y2), color, accent_thickness)
                            cv2.line(annotated_frame, (x1, y2), (x1, y2 - corner_len), color, accent_thickness)
                            # Bottom-right
                            cv2.line(annotated_frame, (x2, y2), (x2 - corner_len, y2), color, accent_thickness)
                            cv2.line(annotated_frame, (x2, y2), (x2, y2 - corner_len), color, accent_thickness)

                        # 3. Draw Pill Label with Class, ID, Confidence
                        label = f"#{track_id} {class_name.capitalize()} {int(conf * 100)}%"
                        font = cv2.FONT_HERSHEY_SIMPLEX
                        font_scale = 0.5
                        thickness = 1
                        (text_w, text_h), baseline = cv2.getTextSize(label, font, font_scale, thickness)
                        
                        pill_y1 = max(0, y1 - text_h - 10)
                        pill_y2 = y1
                        pill_x1 = x1
                        pill_x2 = min(width, x1 + text_w + 12)
                        
                        # Label background pill
                        cv2.rectangle(annotated_frame, (pill_x1, pill_y1), (pill_x2, pill_y2), color, -1)
                        # Text in white
                        cv2.putText(
                            annotated_frame,
                            label,
                            (pill_x1 + 6, pill_y2 - 5),
                            font,
                            font_scale,
                            (255, 255, 255),
                            thickness,
                            cv2.LINE_AA
                        )

        latency_ms = round((time.time() - start_time) * 1000, 1)
        fps = round(1000.0 / latency_ms, 1) if latency_ms > 0 else 30.0

        telemetry = {
            "fps": fps,
            "inference_latency_ms": latency_ms,
            "total_objects": len(detections),
            "frame_width": width,
            "frame_height": height
        }

        return annotated_frame, detections, telemetry

    def reset_tracker(self):
        """Clears trajectories and tracking caches."""
        self.trajectories.clear()
        self.last_seen_times.clear()

# Global Singleton Instance
ai_engine = AIEngine()

import os
import cv2
import time
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session

from ..config import settings
from ..database import SessionLocal
from ..models.video import Video
from ..models.tracking import TrackingSession, TrackingObject
from ..models.detection import Detection
from ..models.activity import ActivityLog
from .ai_engine import AIEngine

# In-memory progress tracker: {video_id: {"progress": 0-100, "status": "processing", "error": None}}
VIDEO_PROGRESS: Dict[int, Dict[str, Any]] = {}

def get_video_progress(video_id: int) -> Dict[str, Any]:
    return VIDEO_PROGRESS.get(video_id, {"progress": 0, "status": "idle", "error": None})

def process_video_background(
    video_id: int,
    confidence_threshold: float = settings.DEFAULT_CONF_THRESHOLD,
    iou_threshold: float = settings.DEFAULT_IOU_THRESHOLD,
    allowed_classes: Optional[list] = None
):
    """
    Background worker function that decodes an uploaded video,
    runs YOLOv8 + ByteTrack object tracking, produces an annotated MP4 video,
    and stores tracking sessions, objects, and detection logs in the database.
    """
    db: Session = SessionLocal()
    VIDEO_PROGRESS[video_id] = {"progress": 0, "status": "processing", "error": None}

    try:
        video = db.query(Video).filter(Video.id == video_id).first()
        if not video:
            VIDEO_PROGRESS[video_id] = {"progress": 0, "status": "failed", "error": "Video record not found"}
            return

        video.status = "processing"
        db.commit()

        input_path = video.filepath
        if not os.path.exists(input_path):
            raise FileNotFoundError(f"Source video file not found at {input_path}")

        cap = cv2.VideoCapture(input_path)
        if not cap.isOpened():
            raise RuntimeError("Failed to open video file via OpenCV")

        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 1280
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 720
        duration = float(total_frames / fps)

        video.fps = round(fps, 2)
        video.total_frames = total_frames
        video.duration = round(duration, 2)
        video.resolution = f"{width}x{height}"
        db.commit()

        # Output Video Path
        processed_filename = f"processed_{video_id}_{video.filename}"
        output_path = os.path.join(str(settings.PROCESSED_DIR), processed_filename)

        # VideoWriter Codec
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        # Initialize Tracking Session
        session_name = f"Video Run: {video.original_name} (#{video_id})"
        tracking_session = TrackingSession(
            user_id=video.user_id,
            source_type="video",
            video_id=video.id,
            session_name=session_name,
            start_time=datetime.utcnow()
        )
        db.add(tracking_session)
        db.commit()
        db.refresh(tracking_session)

        # Separate AI Engine instance for isolated video tracking
        engine = AIEngine(settings.YOLO_MODEL_NAME)

        # In-memory tracking accumulators:
        # {track_id: {"class": str, "first_frame": int, "last_frame": int, "confs": [], "trajectory": []}}
        tracked_objects_data: Dict[int, Dict[str, Any]] = {}
        frame_idx = 0
        detection_batch = []
        BATCH_SIZE = 100

        start_time = datetime.utcnow()

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            frame_idx += 1
            frame_timestamp = start_time + timedelta(seconds=(frame_idx / fps))

            # Run detection & tracking
            annotated_frame, detections, telemetry = engine.process_frame(
                frame=frame,
                confidence_threshold=confidence_threshold,
                iou_threshold=iou_threshold,
                allowed_classes=allowed_classes,
                draw_annotations=True,
                show_trajectories=True,
                persist=True
            )

            # Write annotated frame
            out.write(annotated_frame)

            # Accumulate detection records
            for det in detections:
                tid = det["tracking_id"]
                cls_name = det["object_class"]
                conf = det["confidence"]
                bbox = det["bbox"]
                center = det["center"]

                if tid not in tracked_objects_data:
                    tracked_objects_data[tid] = {
                        "class": cls_name,
                        "first_frame": frame_idx,
                        "last_frame": frame_idx,
                        "confs": [conf],
                        "trajectory": [center],
                        "first_timestamp": frame_timestamp,
                        "last_timestamp": frame_timestamp
                    }
                else:
                    tracked_objects_data[tid]["last_frame"] = frame_idx
                    tracked_objects_data[tid]["last_timestamp"] = frame_timestamp
                    tracked_objects_data[tid]["confs"].append(conf)
                    if len(tracked_objects_data[tid]["trajectory"]) < 100:
                        tracked_objects_data[tid]["trajectory"].append(center)

                # Save sample snapshot on first occurrence or every 30 frames
                snapshot_rel_path = None
                if frame_idx % int(max(1, fps)) == 0 or len(tracked_objects_data[tid]["confs"]) == 1:
                    snapshot_filename = f"snap_vid{video_id}_f{frame_idx}_t{tid}.jpg"
                    snap_abs_path = os.path.join(str(settings.SNAPSHOT_DIR), snapshot_filename)
                    if not os.path.exists(snap_abs_path):
                        # Crop or full annotated thumbnail
                        cv2.imwrite(snap_abs_path, annotated_frame)
                        snapshot_rel_path = f"/static/snapshots/{snapshot_filename}"

                det_record = Detection(
                    session_id=tracking_session.id,
                    tracking_id=tid,
                    object_class=cls_name,
                    confidence=conf,
                    frame_number=frame_idx,
                    timestamp=frame_timestamp,
                    bbox_x1=float(bbox[0]),
                    bbox_y1=float(bbox[1]),
                    bbox_x2=float(bbox[2]),
                    bbox_y2=float(bbox[3]),
                    snapshot_path=snapshot_rel_path
                )
                detection_batch.append(det_record)

                if len(detection_batch) >= BATCH_SIZE:
                    db.bulk_save_objects(detection_batch)
                    db.commit()
                    detection_batch = []

            # Update progress
            progress_pct = min(99, int((frame_idx / total_frames) * 100))
            VIDEO_PROGRESS[video_id]["progress"] = progress_pct

        # Flush any remaining detections
        if detection_batch:
            db.bulk_save_objects(detection_batch)
            db.commit()

        cap.release()
        out.release()

        # Persist Tracked Objects
        total_unique_objects = len(tracked_objects_data)
        tracking_obj_entities = []
        for tid, data in tracked_objects_data.items():
            duration_sec = round((data["last_frame"] - data["first_frame"]) / fps, 2)
            avg_c = round(sum(data["confs"]) / len(data["confs"]), 4)
            t_obj = TrackingObject(
                session_id=tracking_session.id,
                tracking_id=tid,
                object_class=data["class"],
                first_detected_at=data["first_timestamp"],
                last_detected_at=data["last_timestamp"],
                duration_seconds=max(0.1, duration_sec),
                trajectory_data=data["trajectory"],
                avg_confidence=avg_c
            )
            tracking_obj_entities.append(t_obj)

        if tracking_obj_entities:
            db.bulk_save_objects(tracking_obj_entities)
            db.commit()

        # Complete Session & Video
        tracking_session.end_time = datetime.utcnow()
        tracking_session.total_objects = total_unique_objects

        video.status = "completed"
        video.processed_filepath = output_path
        db.commit()

        # Log Activity
        log = ActivityLog(
            user_id=video.user_id,
            action="Processed Video",
            module="Video Module",
            details=f"Completed AI tracking on '{video.original_name}'. Found {total_unique_objects} distinct objects."
        )
        db.add(log)
        db.commit()

        VIDEO_PROGRESS[video_id] = {
            "progress": 100,
            "status": "completed",
            "total_objects": total_unique_objects,
            "error": None
        }

    except Exception as e:
        db.rollback()
        error_msg = str(e)
        VIDEO_PROGRESS[video_id] = {"progress": 0, "status": "failed", "error": error_msg}
        try:
            v = db.query(Video).filter(Video.id == video_id).first()
            if v:
                v.status = "failed"
                v.error_message = error_msg
                db.commit()
        except Exception:
            pass
    finally:
        db.close()

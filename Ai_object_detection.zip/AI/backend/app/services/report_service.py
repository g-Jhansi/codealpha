import os
import csv
from datetime import datetime
from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

from ..config import settings
from ..models.report import Report
from ..models.detection import Detection
from ..models.tracking import TrackingSession

def generate_csv_report(
    db: Session,
    user_id: int,
    title: str = "Object Detection Audit Report",
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    object_classes: Optional[List[str]] = None,
    min_confidence: Optional[float] = None
) -> Report:
    """Generates an RFC 4180 compliant CSV detection history report."""
    query = db.query(Detection)
    if start_date:
        query = query.filter(Detection.timestamp >= start_date)
    if end_date:
        query = query.filter(Detection.timestamp <= end_date)
    if object_classes:
        query = query.filter(Detection.object_class.in_(object_classes))
    if min_confidence is not None:
        query = query.filter(Detection.confidence >= min_confidence)

    detections = query.order_by(Detection.timestamp.desc()).limit(5000).all()

    filename = f"report_{user_id}_{int(datetime.utcnow().timestamp())}.csv"
    filepath = os.path.join(str(settings.REPORT_DIR), filename)

    with open(filepath, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "Detection ID", "Tracking ID", "Object Class",
            "Confidence", "Frame Number", "Timestamp (UTC)",
            "BBox X1", "BBox Y1", "BBox X2", "BBox Y2"
        ])
        for det in detections:
            writer.writerow([
                det.id, det.tracking_id, det.object_class,
                f"{det.confidence:.4f}", det.frame_number,
                det.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                det.bbox_x1, det.bbox_y1, det.bbox_x2, det.bbox_y2
            ])

    report = Report(
        user_id=user_id,
        title=title,
        report_type="csv",
        file_path=filepath,
        date_range_start=start_date,
        date_range_end=end_date,
        filters_applied={
            "classes": object_classes,
            "min_conf": min_confidence,
            "total_records": len(detections)
        }
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report

def generate_pdf_report(
    db: Session,
    user_id: int,
    title: str = "Object Detection & Tracking Audit Report",
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    object_classes: Optional[List[str]] = None,
    min_confidence: Optional[float] = None
) -> Report:
    """Generates a professional executive PDF audit report using ReportLab."""
    query = db.query(Detection)
    if start_date:
        query = query.filter(Detection.timestamp >= start_date)
    if end_date:
        query = query.filter(Detection.timestamp <= end_date)
    if object_classes:
        query = query.filter(Detection.object_class.in_(object_classes))
    if min_confidence is not None:
        query = query.filter(Detection.confidence >= min_confidence)

    detections = query.order_by(Detection.timestamp.desc()).limit(500).all()

    filename = f"report_{user_id}_{int(datetime.utcnow().timestamp())}.pdf"
    filepath = os.path.join(str(settings.REPORT_DIR), filename)

    doc = SimpleDocTemplate(
        filepath,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()

    # Brand Colors
    c_primary = colors.HexColor("#2563EB")
    c_secondary = colors.HexColor("#0F172A")
    c_text_muted = colors.HexColor("#6B7280")
    c_bg_light = colors.HexColor("#F8FAFC")
    c_border = colors.HexColor("#E5E7EB")

    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=c_secondary
    )

    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=c_text_muted
    )

    h2_style = ParagraphStyle(
        'SectionH2',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=16,
        textColor=c_primary,
        spaceBefore=12,
        spaceAfter=6
    )

    body_style = ParagraphStyle(
        'TableBody',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=12,
        textColor=c_secondary
    )

    elements = []

    # 1. Header Banner
    elements.append(Paragraph(title, title_style))
    elements.append(Paragraph(
        f"AI-Based Real-Time Object Detection and Tracking System | Generated on {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC",
        subtitle_style
    ))
    elements.append(Spacer(1, 10))
    elements.append(HRFlowable(width="100%", thickness=2, color=c_primary, spaceBefore=4, spaceAfter=12))

    # 2. Executive KPI Summary
    total_records = len(detections)
    unique_ids = len(set([d.tracking_id for d in detections]))
    avg_conf = (sum([d.confidence for d in detections]) / total_records) if total_records > 0 else 0.0

    class_counts: Dict[str, int] = {}
    for d in detections:
        class_counts[d.object_class] = class_counts.get(d.object_class, 0) + 1
    most_common_class = max(class_counts.items(), key=lambda x: x[1])[0] if class_counts else "None"

    kpi_data = [
        [
            Paragraph("<b>Total Detections Logged</b>", body_style),
            Paragraph(f"<b>{total_records}</b>", body_style),
            Paragraph("<b>Unique Tracked Objects</b>", body_style),
            Paragraph(f"<b>{unique_ids}</b>", body_style)
        ],
        [
            Paragraph("<b>Average Confidence</b>", body_style),
            Paragraph(f"<b>{avg_conf * 100:.1f}%</b>", body_style),
            Paragraph("<b>Most Frequent Class</b>", body_style),
            Paragraph(f"<b>{most_common_class.capitalize()}</b>", body_style)
        ]
    ]
    kpi_table = Table(kpi_data, colWidths=[1.8 * inch, 1.2 * inch, 1.8 * inch, 1.7 * inch])
    kpi_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), c_bg_light),
        ('BOX', (0, 0), (-1, -1), 1, c_border),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, c_border),
        ('PADDING', (0, 0), (-1, -1), 8),
    ]))
    elements.append(kpi_table)
    elements.append(Spacer(1, 14))

    # 3. Class Breakdown Summary Table
    elements.append(Paragraph("Object Category Breakdown", h2_style))
    cat_rows = [["Object Class", "Count", "Percentage"]]
    for cls_name, count in sorted(class_counts.items(), key=lambda x: x[1], reverse=True):
        pct = (count / total_records * 100) if total_records > 0 else 0
        cat_rows.append([cls_name.capitalize(), str(count), f"{pct:.1f}%"])

    if len(cat_rows) > 1:
        cat_table = Table(cat_rows, colWidths=[2.5 * inch, 2.0 * inch, 2.0 * inch])
        cat_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), c_primary),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
            ('GRID', (0, 0), (-1, -1), 0.5, c_border),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, c_bg_light]),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(cat_table)
        elements.append(Spacer(1, 14))

    # 4. Detailed Telemetry Log Table
    elements.append(Paragraph("Detection Records (Latest 500 Events)", h2_style))
    log_rows = [["Time (UTC)", "Track ID", "Class", "Confidence", "Frame #", "Bounding Box"]]
    for det in detections[:500]:
        bbox_str = f"[{int(det.bbox_x1)}, {int(det.bbox_y1)}, {int(det.bbox_x2)}, {int(det.bbox_y2)}]"
        log_rows.append([
            det.timestamp.strftime("%H:%M:%S"),
            f"#{det.tracking_id}",
            det.object_class.capitalize(),
            f"{int(det.confidence * 100)}%",
            str(det.frame_number),
            bbox_str
        ])

    log_table = Table(log_rows, colWidths=[1.1 * inch, 0.9 * inch, 1.2 * inch, 1.0 * inch, 0.9 * inch, 1.9 * inch])
    log_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), c_secondary),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, c_border),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, c_bg_light]),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    elements.append(log_table)

    doc.build(elements)

    report = Report(
        user_id=user_id,
        title=title,
        report_type="pdf",
        file_path=filepath,
        date_range_start=start_date,
        date_range_end=end_date,
        filters_applied={
            "classes": object_classes,
            "min_conf": min_confidence,
            "total_records": total_records
        }
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report

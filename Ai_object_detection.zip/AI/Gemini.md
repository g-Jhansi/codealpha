You are an expert Full Stack AI Software Engineer, UI/UX Designer, Database Architect, and Computer Vision Engineer.

Your task is to design and develop a production-quality Final Year Engineering Project titled:

**"AI-Based Real-Time Object Detection and Tracking System."**

The application should be modern, scalable, responsive, and follow industry-standard software architecture.

## Objective

Develop a web application capable of detecting and tracking multiple objects in real time using Artificial Intelligence. The application should support both live webcam input and uploaded videos. It should detect multiple object classes, assign a unique tracking ID to each detected object, maintain the same ID while the object moves, store detection history, generate reports, and display analytics.

---

## Technology Stack

Frontend:

* React.js
* HTML5
* CSS3
* JavaScript
* Responsive UI

Backend:

* Python FastAPI (or Flask)

Artificial Intelligence:

* YOLOv8
* OpenCV
* ByteTrack (or DeepSORT)

Database:

* MySQL

Charts:

* Chart.js

Reports:

* PDF
* CSV

---

## User Roles

Administrator

Standard User

---

## Modules

### Authentication

* Login
* Registration
* Forgot Password
* Logout
* Profile Management

### Dashboard

Display

* Total Videos
* Total Detections
* Total Tracking Sessions
* Active Camera
* Detection Statistics
* Recent Activities

### Video Module

* Upload Video
* View Uploaded Videos
* Delete Video
* Play Video

Supported formats:

* mp4
* avi
* mov

### Live Camera Module

* Start Camera
* Stop Camera
* Live Preview
* Capture Screenshot

### AI Detection Module

Detect

* Person
* Car
* Bike
* Bus
* Truck
* Dog
* Cat
* Laptop
* Mobile Phone
* Chair
* Bottle

Display

* Bounding Box
* Object Label
* Confidence Score

### Object Tracking Module

Assign a unique tracking ID to every detected object.

The tracking ID must remain constant while the object is visible.

Track

* Start Time
* End Time
* Duration
* Object Path

### Detection History

Store

* Object Name
* Detection Time
* Confidence
* Video Name
* Frame Number
* Tracking ID

Provide

* Search
* Filter
* Sort

### Analytics

Display

* Daily Detection Count
* Weekly Detection Count
* Monthly Detection Count
* Object Frequency
* Most Detected Object
* Average Confidence

Use interactive charts.

### Report Module

Generate

* PDF
* CSV

Include

* Date
* Time
* Object
* Confidence
* Tracking ID

### Settings

* Camera Configuration
* Detection Threshold
* Confidence Threshold
* User Profile
* Password Change

---

## Database

Create normalized MySQL tables for

Users

Videos

Detections

Tracking

Reports

Activity Logs

---

## UI Requirements

Design a clean, modern dashboard.

Use cards, charts, tables, dialogs, pagination, and responsive layouts.

Maintain consistent spacing, colors, typography, and navigation.

---

## Functional Requirements

The system must

* Detect objects from webcam
* Detect objects from uploaded videos
* Track multiple objects simultaneously
* Maintain unique IDs
* Store detection history
* Generate reports
* Display analytics
* Support searching and filtering
* Be responsive on desktop and laptop screens

---

## Non-Functional Requirements

* Fast response time
* Modular architecture
* Secure authentication
* Proper error handling
* Scalable design
* Clean code
* Well-documented APIs

---

## Deliverables

Generate

* Complete frontend
* Complete backend
* AI integration
* Database schema
* REST APIs
* UI pages
* Source code
* Project documentation
* Installation guide
* README
* Testing documentation

The code should be modular, production-ready, and suitable for a Final Year Engineering Project.

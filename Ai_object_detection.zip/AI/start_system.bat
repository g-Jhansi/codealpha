@echo off
title VisionTrack AI - System Launcher
echo ===================================================================
echo Starting VisionTrack AI - Real-Time Detection and Tracking System
echo ===================================================================
echo.
echo Starting FastAPI Backend on http://localhost:8000 ...
start "VisionTrack Backend" cmd /c "run_backend.bat"

echo Waiting 3 seconds for backend initialization...
timeout /t 3 /nobreak >nul

echo Starting React Frontend on http://localhost:5173 ...
start "VisionTrack Frontend" cmd /c "run_frontend.bat"

echo.
echo ===================================================================
echo Both services are launching in separate windows:
echo - Frontend Dashboard: http://localhost:5173
echo - Backend Swagger API Docs: http://localhost:8000/docs
echo.
echo Default Demo Credentials:
echo - Administrator: admin / Admin@123
echo - Standard User: user / User@123
echo ===================================================================

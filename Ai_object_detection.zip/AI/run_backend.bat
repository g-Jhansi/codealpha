@echo off
title VisionTrack AI - FastAPI Backend Server
echo ===================================================
echo VisionTrack AI Backend Server (FastAPI + YOLOv8)
echo ===================================================
cd /d "%~dp0"
python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload
pause

import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Navbar from './Navbar';

const Layout = () => {
  return (
    <div style={{ display: 'flex', minHeight: '100vh', backgroundColor: 'var(--color-bg)' }}>
      <Sidebar />
      <div style={{
        marginLeft: 'var(--sidebar-width)',
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column',
        minWidth: 0
      }}>
        <Navbar />
        <main style={{
          padding: '32px',
          flexGrow: 1,
          maxWidth: '1600px',
          width: '100%',
          margin: '0 auto'
        }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;

import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Camera,
  Video,
  History,
  BarChart3,
  FileText,
  Settings,
  Cpu,
  LogOut,
  ShieldCheck,
  User
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Sidebar = () => {
  const { user, logout } = useAuth();

  const navItems = [
    { label: 'Dashboard', path: '/', icon: LayoutDashboard },
    { label: 'Live Camera', path: '/live', icon: Camera },
    { label: 'Video Module', path: '/videos', icon: Video },
    { label: 'Detection History', path: '/history', icon: History },
    { label: 'Analytics', path: '/analytics', icon: BarChart3 },
    { label: 'Reports', path: '/reports', icon: FileText },
    { label: 'Settings', path: '/settings', icon: Settings },
  ];

  return (
    <aside style={{
      width: 'var(--sidebar-width)',
      height: '100vh',
      backgroundColor: '#FFFFFF',
      borderRight: '1px solid var(--color-border)',
      display: 'flex',
      flexDirection: 'column',
      position: 'fixed',
      top: 0,
      left: 0,
      zIndex: 40
    }}>
      {/* Brand Logo Header (Brand Guideline: Minimal AI + Camera icon) */}
      <div style={{
        height: 'var(--navbar-height)',
        padding: '0 24px',
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        borderBottom: '1px solid var(--color-border)'
      }}>
        <div style={{
          width: '38px',
          height: '38px',
          backgroundColor: 'var(--color-primary)',
          borderRadius: '10px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#FFFFFF',
          boxShadow: 'var(--shadow-primary)'
        }}>
          <Camera size={20} />
        </div>
        <div>
          <div style={{
            fontSize: '15px',
            fontWeight: 700,
            fontFamily: 'var(--font-heading)',
            color: 'var(--color-secondary)',
            letterSpacing: '-0.3px',
            lineHeight: 1.1
          }}>
            VisionTrack AI
          </div>
          <div style={{
            fontSize: '11px',
            fontWeight: 500,
            color: 'var(--color-text-secondary)',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            marginTop: '2px'
          }}>
            <Cpu size={10} color="var(--color-primary)" /> YOLOv8 + ByteTrack
          </div>
        </div>
      </div>

      {/* Navigation Links */}
      <nav style={{
        padding: '20px 14px',
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column',
        gap: '4px',
        overflowY: 'auto'
      }}>
        <div style={{
          fontSize: '11px',
          fontWeight: 600,
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          color: 'var(--color-text-muted)',
          padding: '0 12px 8px 12px'
        }}>
          Main Navigation
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              style={({ isActive }) => ({
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                padding: '10px 14px',
                borderRadius: 'var(--radius-lg)',
                fontSize: '14px',
                fontWeight: isActive ? 600 : 500,
                color: isActive ? '#FFFFFF' : 'var(--color-text-secondary)',
                backgroundColor: isActive ? 'var(--color-primary)' : 'transparent',
                boxShadow: isActive ? 'var(--shadow-primary)' : 'none',
                textDecoration: 'none',
                transition: 'all var(--transition-fast)'
              })}
            >
              <Icon size={18} />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* User Session Profile Chip & Logout */}
      <div style={{
        padding: '16px 14px',
        borderTop: '1px solid var(--color-border)',
        backgroundColor: '#F8FAFC'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          padding: '8px 10px',
          borderRadius: 'var(--radius-lg)',
          backgroundColor: '#FFFFFF',
          border: '1px solid var(--color-border)',
          marginBottom: '8px'
        }}>
          <div style={{
            width: '34px',
            height: '34px',
            borderRadius: '50%',
            backgroundColor: 'var(--color-primary-light)',
            color: 'var(--color-primary)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 600,
            fontSize: '14px'
          }}>
            {user?.username ? user.username.charAt(0).toUpperCase() : 'U'}
          </div>
          <div style={{ overflow: 'hidden', flexGrow: 1 }}>
            <div style={{
              fontSize: '13px',
              fontWeight: 600,
              color: 'var(--color-secondary)',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis'
            }}>
              {user?.full_name || user?.username || 'Operator'}
            </div>
            <div style={{
              fontSize: '11px',
              color: 'var(--color-text-secondary)',
              display: 'flex',
              alignItems: 'center',
              gap: '4px'
            }}>
              {user?.role === 'admin' ? (
                <span className="badge badge-primary" style={{ padding: '1px 6px', fontSize: '10px' }}>
                  <ShieldCheck size={10} /> Admin
                </span>
              ) : (
                <span className="badge badge-secondary" style={{ padding: '1px 6px', fontSize: '10px' }}>
                  <User size={10} /> Standard
                </span>
              )}
            </div>
          </div>
        </div>

        <button
          onClick={logout}
          className="btn btn-ghost"
          style={{
            width: '100%',
            justifyContent: 'flex-start',
            gap: '8px',
            padding: '8px 12px',
            fontSize: '13px',
            color: 'var(--color-danger)'
          }}
        >
          <LogOut size={16} /> Log Out
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;

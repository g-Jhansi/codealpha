import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, Video, Bell, Sparkles, Activity } from 'lucide-react';

const Navbar = () => {
  const navigate = useNavigate();

  return (
    <header
      className="glass-panel"
      style={{
        height: 'var(--navbar-height)',
        position: 'sticky',
        top: 0,
        zIndex: 30,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 32px',
        borderBottom: '1px solid var(--color-border)'
      }}
    >
      {/* Left side: System Status & Camera Indicator */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '6px 12px',
          backgroundColor: '#FFFFFF',
          borderRadius: 'var(--radius-full)',
          border: '1px solid var(--color-border)',
          fontSize: '12px',
          fontWeight: 600,
          color: 'var(--color-secondary)',
          boxShadow: 'var(--shadow-sm)'
        }}>
          <span style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            backgroundColor: 'var(--color-success)',
            display: 'inline-block',
            boxShadow: '0 0 8px var(--color-success)'
          }} />
          <span>Active Camera Ready</span>
        </div>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          fontSize: '12px',
          color: 'var(--color-text-secondary)',
          fontWeight: 500
        }}>
          <Sparkles size={14} color="var(--color-primary)" />
          <span>Inference: <b style={{ color: 'var(--color-secondary)' }}>YOLOv8 Nano</b></span>
        </div>
      </div>

      {/* Right side: Quick Actions & Notifications */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <button
          onClick={() => navigate('/videos')}
          className="btn btn-secondary btn-sm"
        >
          <Video size={15} />
          Upload Video
        </button>

        <button
          onClick={() => navigate('/live')}
          className="btn btn-primary btn-sm"
        >
          <Camera size={15} />
          Live Camera Stream
        </button>

        <div style={{
          width: '1px',
          height: '24px',
          backgroundColor: 'var(--color-border)',
          margin: '0 4px'
        }} />

        <div
          title="System Online"
          style={{
            width: '36px',
            height: '36px',
            borderRadius: '50%',
            backgroundColor: '#FFFFFF',
            border: '1px solid var(--color-border)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--color-text-secondary)',
            cursor: 'default'
          }}
        >
          <Activity size={17} color="var(--color-primary)" />
        </div>
      </div>
    </header>
  );
};

export default Navbar;

import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Calendar,
  Layers,
  FileSpreadsheet,
  CheckCircle2,
  Filter,
  RefreshCw,
  Plus
} from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

const TARGET_CLASSES_LIST = [
  'person', 'car', 'bicycle', 'motorcycle', 'bus', 'truck',
  'dog', 'cat', 'laptop', 'cell phone', 'chair', 'bottle'
];

const ReportsPage = () => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  // Modal / Form state
  const [showModal, setShowModal] = useState(false);
  const [reportTitle, setReportTitle] = useState('AI Tracking Audit Report');
  const [reportType, setReportType] = useState('pdf');
  const [selectedClasses, setSelectedClasses] = useState([]);
  const [minConf, setMinConf] = useState('0.35');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const { addToast } = useToast();

  const fetchReports = async () => {
    try {
      const res = await api.get('/reports/');
      setReports(res.data);
    } catch (err) {
      console.error('Failed to load reports:', err);
      addToast('Could not load reports list', 'danger');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  const handleGenerateReport = async (e) => {
    e.preventDefault();
    setGenerating(true);

    try {
      const payload = {
        title: reportTitle,
        report_type: reportType,
        min_confidence: minConf ? parseFloat(minConf) : null,
        object_classes: selectedClasses.length > 0 ? selectedClasses : null,
        start_date: startDate ? new Date(startDate).toISOString() : null,
        end_date: endDate ? new Date(endDate).toISOString() : null
      };

      const res = await api.post('/reports/generate', payload);
      addToast(`${reportType.toUpperCase()} Report generated successfully!`, 'success');
      setShowModal(false);
      fetchReports();

      // Automatically trigger download
      window.open(`http://localhost:8000${res.data.download_url}`, '_blank');
    } catch (err) {
      console.error('Failed to generate report:', err);
      addToast('Failed to generate report', 'danger');
    } finally {
      setGenerating(false);
    }
  };

  const toggleClassSelect = (cls) => {
    if (selectedClasses.includes(cls)) {
      setSelectedClasses(selectedClasses.filter((c) => c !== cls));
    } else {
      setSelectedClasses([...selectedClasses, cls]);
    }
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '28px',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--color-secondary)' }}>
            Compliance & Audit Reports
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
            Generate and archive regulatory-compliant PDF and CSV surveillance telemetry reports.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="btn btn-primary"
        >
          <Plus size={16} /> Generate New Report
        </button>
      </div>

      {/* Reports List Table */}
      <div className="card">
        <div className="card-header">
          <div>
            <h3 className="card-title" style={{ fontSize: '16px' }}>
              Generated Report Archives ({reports.length})
            </h3>
            <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>
              Historical reports ready for download and auditing
            </p>
          </div>
          <button
            onClick={fetchReports}
            className="btn btn-ghost btn-sm"
            title="Refresh reports"
          >
            <RefreshCw size={14} />
          </button>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Report Title</th>
                <th>Format</th>
                <th>Created At (UTC)</th>
                <th>Total Records</th>
                <th>Applied Filters</th>
                <th>Download</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '36px', color: 'var(--color-text-muted)' }}>
                    Loading reports...
                  </td>
                </tr>
              ) : reports.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '36px', color: 'var(--color-text-muted)' }}>
                    No reports generated yet. Click "Generate New Report" to create your first report.
                  </td>
                </tr>
              ) : (
                reports.map((rep) => (
                  <tr key={rep.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div style={{
                          width: '34px',
                          height: '34px',
                          borderRadius: '8px',
                          backgroundColor: rep.report_type === 'pdf' ? 'var(--color-primary-light)' : '#F0FDF4',
                          color: rep.report_type === 'pdf' ? 'var(--color-primary)' : 'var(--color-success)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          {rep.report_type === 'pdf' ? <FileText size={18} /> : <FileSpreadsheet size={18} />}
                        </div>
                        <span style={{ fontWeight: 600, color: 'var(--color-secondary)' }}>
                          {rep.title}
                        </span>
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${rep.report_type === 'pdf' ? 'badge-primary' : 'badge-success'}`}>
                        {rep.report_type.toUpperCase()}
                      </span>
                    </td>
                    <td style={{ color: 'var(--color-text-secondary)', fontSize: '13px' }}>
                      {new Date(rep.created_at).toLocaleString()}
                    </td>
                    <td className="font-mono">
                      {rep.filters_applied?.total_records ?? 'N/A'}
                    </td>
                    <td style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>
                      {rep.filters_applied?.classes ? rep.filters_applied.classes.join(', ') : 'All Classes'}
                    </td>
                    <td>
                      <a
                        href={`http://localhost:8000${rep.download_url}`}
                        target="_blank"
                        rel="noreferrer"
                        className="btn btn-secondary btn-sm"
                        style={{ display: 'inline-flex', padding: '6px 12px' }}
                      >
                        <Download size={14} /> Download
                      </a>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Generate Report */}
      {showModal && (
        <div
          onClick={() => setShowModal(false)}
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.75)',
            backdropFilter: 'blur(8px)',
            zIndex: 999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '24px'
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="card animate-fade-in"
            style={{
              maxWidth: '560px',
              width: '100%',
              padding: '28px',
              backgroundColor: '#FFFFFF'
            }}
          >
            <h3 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--color-secondary)', marginBottom: '4px' }}>
              Generate Custom Audit Report
            </h3>
            <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', marginBottom: '20px' }}>
              Select report specifications, target format, and observation parameters.
            </p>

            <form onSubmit={handleGenerateReport}>
              <div className="form-group">
                <label className="form-label">Report Document Title</label>
                <input
                  type="text"
                  className="form-input"
                  value={reportTitle}
                  onChange={(e) => setReportTitle(e.target.value)}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                <div className="form-group">
                  <label className="form-label">Export Format</label>
                  <select
                    className="form-select"
                    value={reportType}
                    onChange={(e) => setReportType(e.target.value)}
                  >
                    <option value="pdf">PDF Executive Audit</option>
                    <option value="csv">CSV Spreadsheet Log</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Min Confidence</label>
                  <select
                    className="form-select"
                    value={minConf}
                    onChange={(e) => setMinConf(e.target.value)}
                  >
                    <option value="0.30">30% (Loose)</option>
                    <option value="0.35">35% (Default)</option>
                    <option value="0.60">60% (Strict)</option>
                    <option value="0.80">80% (High Confidence)</option>
                  </select>
                </div>
              </div>

              {/* Class Filter Tags */}
              <div className="form-group">
                <label className="form-label">Include Specific Object Classes (Optional)</label>
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '6px',
                  maxHeight: '110px',
                  overflowY: 'auto',
                  padding: '4px 0'
                }}>
                  {TARGET_CLASSES_LIST.map((cls) => {
                    const isSelected = selectedClasses.includes(cls);
                    return (
                      <button
                        key={cls}
                        type="button"
                        onClick={() => toggleClassSelect(cls)}
                        style={{
                          padding: '4px 10px',
                          borderRadius: 'var(--radius-sm)',
                          border: '1px solid',
                          borderColor: isSelected ? 'var(--color-primary)' : 'var(--color-border)',
                          backgroundColor: isSelected ? 'var(--color-primary-light)' : '#FFFFFF',
                          color: isSelected ? 'var(--color-primary)' : 'var(--color-text-secondary)',
                          fontSize: '11px',
                          fontWeight: isSelected ? 600 : 500,
                          cursor: 'pointer',
                          textTransform: 'capitalize'
                        }}
                      >
                        {cls}
                      </button>
                    );
                  })}
                </div>
                <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>
                  {selectedClasses.length === 0 ? 'All detected classes will be included.' : `${selectedClasses.length} classes selected.`}
                </span>
              </div>

              {/* Action Buttons */}
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '24px' }}>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn btn-ghost"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={generating}
                  className="btn btn-primary"
                >
                  <Download size={16} />
                  {generating ? 'Compiling Document...' : 'Generate & Download'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportsPage;

import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  TrendingUp,
  Target,
  Award,
  Zap,
  Calendar,
  Layers,
  PieChart
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const AnalyticsPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [timeframe, setTimeframe] = useState('daily'); // 'daily', 'weekly', 'monthly'
  const [loading, setLoading] = useState(true);
  const { addToast } = useToast();

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const res = await api.get('/analytics/summary');
        setAnalytics(res.data);
      } catch (err) {
        console.error('Failed to load analytics:', err);
        addToast('Failed to fetch analytics statistics', 'danger');
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, [addToast]);

  // Dynamic Trend Data based on selected timeframe
  let trendLabels = [];
  let trendValues = [];

  if (timeframe === 'daily') {
    trendLabels = analytics?.daily_trends?.map((t) => t.date) || [];
    trendValues = analytics?.daily_trends?.map((t) => t.count) || [];
  } else if (timeframe === 'weekly') {
    trendLabels = analytics?.weekly_trends?.map((t) => t.date) || [];
    trendValues = analytics?.weekly_trends?.map((t) => t.count) || [];
  } else {
    trendLabels = analytics?.monthly_trends?.map((t) => t.date) || [];
    trendValues = analytics?.monthly_trends?.map((t) => t.count) || [];
  }

  const trendsChartData = {
    labels: trendLabels,
    datasets: [
      {
        label: `${timeframe.toUpperCase()} Detections`,
        data: trendValues,
        borderColor: '#2563EB',
        backgroundColor: 'rgba(37, 99, 235, 0.12)',
        fill: true,
        tension: 0.35,
        pointBackgroundColor: '#2563EB',
        pointBorderColor: '#FFFFFF',
        pointBorderWidth: 2,
        pointRadius: 5
      }
    ]
  };

  // Object Frequency Bar Chart
  const barLabels = analytics?.object_frequencies?.map((f) => f.object_class.toUpperCase()) || [];
  const barValues = analytics?.object_frequencies?.map((f) => f.count) || [];

  const barChartData = {
    labels: barLabels,
    datasets: [
      {
        label: 'Detection Occurrences',
        data: barValues,
        backgroundColor: '#2563EB',
        borderRadius: 8
      }
    ]
  };

  // Confidence Distribution Histogram
  const confLabels = Object.keys(analytics?.confidence_distribution || {});
  const confValues = Object.values(analytics?.confidence_distribution || {});

  const confChartData = {
    labels: confLabels,
    datasets: [
      {
        label: 'Confidence Bin Count',
        data: confValues,
        backgroundColor: '#22C55E',
        borderRadius: 8
      }
    ]
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '28px',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--color-secondary)' }}>
            AI Analytics & Object Intelligence
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
            Comprehensive statistical telemetry, object distribution curves, and detection trends.
          </p>
        </div>

        {/* Timeframe Selector Pill */}
        <div style={{
          display: 'flex',
          backgroundColor: '#FFFFFF',
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius-lg)',
          padding: '4px',
          boxShadow: 'var(--shadow-sm)'
        }}>
          {['daily', 'weekly', 'monthly'].map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              style={{
                padding: '6px 14px',
                border: 'none',
                borderRadius: 'var(--radius-md)',
                fontSize: '12px',
                fontWeight: 600,
                cursor: 'pointer',
                textTransform: 'capitalize',
                backgroundColor: timeframe === tf ? 'var(--color-primary)' : 'transparent',
                color: timeframe === tf ? '#FFFFFF' : 'var(--color-text-secondary)',
                transition: 'all var(--transition-fast)'
              }}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* 4 Summary Highlight Cards */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-icon-wrapper" style={{ backgroundColor: 'var(--color-primary-light)', color: 'var(--color-primary)' }}>
            <Target size={24} />
          </div>
          <div className="kpi-info">
            <span className="kpi-label">Total Detections</span>
            <span className="kpi-value">{analytics?.total_detections || 0}</span>
            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
              Across all sessions
            </span>
          </div>
        </div>

        <div className="kpi-card">
          <div className="kpi-icon-wrapper" style={{ backgroundColor: '#F0FDF4', color: 'var(--color-success)' }}>
            <Award size={24} />
          </div>
          <div className="kpi-info">
            <span className="kpi-label">Most Detected Object</span>
            <span className="kpi-value" style={{ textTransform: 'capitalize', fontSize: '22px' }}>
              {analytics?.most_detected_object || 'None'}
            </span>
            <span style={{ fontSize: '11px', color: 'var(--color-success)', fontWeight: 600, marginTop: '2px' }}>
              {analytics?.most_detected_count || 0} occurrences
            </span>
          </div>
        </div>

        <div className="kpi-card">
          <div className="kpi-icon-wrapper" style={{ backgroundColor: '#FFFBEB', color: 'var(--color-warning)' }}>
            <TrendingUp size={24} />
          </div>
          <div className="kpi-info">
            <span className="kpi-label">Average Confidence</span>
            <span className="kpi-value">{analytics?.average_confidence || 0}%</span>
            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
              YOLOv8 inference confidence
            </span>
          </div>
        </div>

        <div className="kpi-card">
          <div className="kpi-icon-wrapper" style={{ backgroundColor: '#EFF6FF', color: 'var(--color-primary)' }}>
            <Zap size={24} />
          </div>
          <div className="kpi-info">
            <span className="kpi-label">Tracking Sessions</span>
            <span className="kpi-value">{analytics?.total_tracking_sessions || 0}</span>
            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
              Live & Video runs
            </span>
          </div>
        </div>
      </div>

      {/* Primary Trend Chart */}
      <div className="card" style={{ marginBottom: '28px' }}>
        <div className="card-header">
          <div>
            <h3 className="card-title">
              Temporal Activity Volume ({timeframe.toUpperCase()} Progression)
            </h3>
            <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>
              Dynamic progression of detected objects over time
            </p>
          </div>
          <span className="badge badge-primary">Interactive Timeline</span>
        </div>
        <div style={{ height: '300px', width: '100%' }}>
          <Line
            data={trendsChartData}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: { grid: { color: '#F1F5F9' }, ticks: { precision: 0 } },
                x: { grid: { display: false } }
              }
            }}
          />
        </div>
      </div>

      {/* Two Column Grid: Object Class Frequency & Confidence Distribution */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '24px'
      }}>
        {/* Frequency Bar Chart */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Class Frequency Ranking</h3>
              <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>
                Comparative occurrences by object class
              </p>
            </div>
            <BarChart3 size={18} color="var(--color-primary)" />
          </div>
          <div style={{ height: '260px', width: '100%' }}>
            <Bar
              data={barChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: { grid: { color: '#F1F5F9' }, ticks: { precision: 0 } },
                  x: { grid: { display: false } }
                }
              }}
            />
          </div>
        </div>

        {/* Confidence Distribution */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Confidence Distribution</h3>
              <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>
                Histogram of detection prediction certainty
              </p>
            </div>
            <TrendingUp size={18} color="var(--color-success)" />
          </div>
          <div style={{ height: '260px', width: '100%' }}>
            <Bar
              data={confChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: { grid: { color: '#F1F5F9' }, ticks: { precision: 0 } },
                  x: { grid: { display: false } }
                }
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;

import React, { useState, useEffect, useRef } from 'react';
import {
  UploadCloud,
  Play,
  Trash2,
  Cpu,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileVideo,
  RefreshCw,
  Sparkles,
  Layers,
  ChevronRight
} from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

const VideoManagementPage = () => {
  const [videos, setVideos] = useState([]);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [showProcessed, setShowProcessed] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processingStatus, setProcessingStatus] = useState({}); // {videoId: {progress, status}}
  const [loading, setLoading] = useState(true);

  const fileInputRef = useRef(null);
  const { addToast } = useToast();

  const fetchVideos = async () => {
    try {
      const res = await api.get('/videos/');
      setVideos(res.data);
      if (res.data.length > 0 && !selectedVideo) {
        setSelectedVideo(res.data[0]);
      }
    } catch (err) {
      console.error('Failed to load videos:', err);
      addToast('Could not load videos', 'danger');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVideos();
  }, []);

  // Poll progress for videos that are currently processing
  useEffect(() => {
    const activeProcessingVideos = videos.filter((v) => v.status === 'processing');
    if (activeProcessingVideos.length === 0) return;

    const interval = setInterval(async () => {
      for (const vid of activeProcessingVideos) {
        try {
          const res = await api.get(`/videos/${vid.id}/progress`);
          setProcessingStatus((prev) => ({ ...prev, [vid.id]: res.data }));
          if (res.data.status === 'completed' || res.data.status === 'failed') {
            fetchVideos();
            if (res.data.status === 'completed') {
              addToast(`Video '${vid.original_name}' processed successfully!`, 'success');
            } else {
              addToast(`Video processing failed: ${res.data.error}`, 'danger');
            }
          }
        } catch (err) {
          console.error(`Error polling progress for video ${vid.id}:`, err);
        }
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [videos, addToast]);

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const ext = file.name.split('.').pop().toLowerCase();
    if (!['mp4', 'avi', 'mov'].includes(ext)) {
      addToast('Only .mp4, .avi, and .mov video formats are supported', 'danger');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    setUploading(true);
    setUploadProgress(0);

    try {
      const res = await api.post('/videos/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(percent);
        }
      });
      addToast(`Video '${file.name}' uploaded successfully`, 'success');
      await fetchVideos();
      setSelectedVideo(res.data);
    } catch (err) {
      const msg = err.response?.data?.detail || 'Failed to upload video';
      addToast(msg, 'danger');
    } finally {
      setUploading(false);
      setUploadProgress(0);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleProcessVideo = async (videoId) => {
    try {
      await api.post(`/videos/${videoId}/process`, {
        confidence_threshold: 0.35,
        iou_threshold: 0.45
      });
      addToast('AI detection and tracking started in background', 'info');
      // Optimistically update status
      setVideos((prev) =>
        prev.map((v) => (v.id === videoId ? { ...v, status: 'processing' } : v))
      );
    } catch (err) {
      const msg = err.response?.data?.detail || 'Failed to trigger video processing';
      addToast(msg, 'danger');
    }
  };

  const handleDeleteVideo = async (videoId) => {
    if (!window.confirm('Are you sure you want to delete this video and all associated detections?')) {
      return;
    }

    try {
      await api.delete(`/videos/${videoId}`);
      addToast('Video deleted successfully', 'success');
      if (selectedVideo?.id === videoId) {
        setSelectedVideo(null);
      }
      await fetchVideos();
    } catch (err) {
      addToast('Failed to delete video', 'danger');
    }
  };

  return (
    <div className="animate-fade-in">
      {/* Page Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '28px',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--color-secondary)' }}>
            Video Processing & Gallery
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
            Upload, inspect, and analyze pre-recorded video files with the YOLOv8 and ByteTrack pipeline.
          </p>
        </div>

        <div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".mp4,.avi,.mov"
            style={{ display: 'none' }}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="btn btn-primary"
          >
            <UploadCloud size={18} />
            {uploading ? `Uploading ${uploadProgress}%...` : 'Upload New Video'}
          </button>
        </div>
      </div>

      {/* Main Content Layout */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '2fr 1fr',
        gap: '24px'
      }}>
        {/* Left Column: Video Player & Inspection */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div className="card" style={{ padding: '20px' }}>
            {selectedVideo ? (
              <div>
                {/* Player Toolbar */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '14px',
                  flexWrap: 'wrap',
                  gap: '10px'
                }}>
                  <div>
                    <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--color-secondary)' }}>
                      {selectedVideo.original_name}
                    </h3>
                    <span style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>
                      {selectedVideo.resolution} • {selectedVideo.fps} FPS • {selectedVideo.duration}s
                    </span>
                  </div>

                  {/* Toggle between processed and original */}
                  {selectedVideo.status === 'completed' && (
                    <div style={{
                      display: 'flex',
                      backgroundColor: '#F1F5F9',
                      borderRadius: 'var(--radius-md)',
                      padding: '3px'
                    }}>
                      <button
                        onClick={() => setShowProcessed(true)}
                        style={{
                          padding: '6px 12px',
                          border: 'none',
                          borderRadius: 'var(--radius-sm)',
                          fontSize: '12px',
                          fontWeight: 600,
                          cursor: 'pointer',
                          backgroundColor: showProcessed ? '#FFFFFF' : 'transparent',
                          color: showProcessed ? 'var(--color-primary)' : 'var(--color-text-secondary)',
                          boxShadow: showProcessed ? 'var(--shadow-sm)' : 'none'
                        }}
                      >
                        AI Annotated
                      </button>
                      <button
                        onClick={() => setShowProcessed(false)}
                        style={{
                          padding: '6px 12px',
                          border: 'none',
                          borderRadius: 'var(--radius-sm)',
                          fontSize: '12px',
                          fontWeight: 600,
                          cursor: 'pointer',
                          backgroundColor: !showProcessed ? '#FFFFFF' : 'transparent',
                          color: !showProcessed ? 'var(--color-primary)' : 'var(--color-text-secondary)',
                          boxShadow: !showProcessed ? 'var(--shadow-sm)' : 'none'
                        }}
                      >
                        Raw Source
                      </button>
                    </div>
                  )}
                </div>

                {/* HTML5 Video Player */}
                <div style={{
                  backgroundColor: '#0F172A',
                  borderRadius: 'var(--radius-lg)',
                  overflow: 'hidden',
                  width: '100%',
                  aspectRatio: '16/9',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '1px solid var(--color-border)'
                }}>
                  <video
                    key={`${selectedVideo.id}-${showProcessed}`}
                    controls
                    autoPlay={false}
                    style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                    src={`http://localhost:8000/api/videos/${selectedVideo.id}/file?processed=${showProcessed && selectedVideo.status === 'completed'}`}
                  >
                    Your browser does not support HTML5 video playback.
                  </video>
                </div>

                {/* Video Info Strip & Action */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginTop: '16px',
                  paddingTop: '16px',
                  borderTop: '1px solid var(--color-border)',
                  flexWrap: 'wrap',
                  gap: '12px'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-secondary)' }}>
                      Status:
                    </span>
                    {selectedVideo.status === 'completed' ? (
                      <span className="badge badge-success">
                        <CheckCircle2 size={12} /> Completed
                      </span>
                    ) : selectedVideo.status === 'processing' ? (
                      <span className="badge badge-warning">
                        <RefreshCw size={12} className="animate-pulse" /> Processing ({processingStatus[selectedVideo.id]?.progress || 0}%)
                      </span>
                    ) : (
                      <span className="badge badge-secondary">
                        Ready to Process
                      </span>
                    )}
                  </div>

                  <div style={{ display: 'flex', gap: '10px' }}>
                    {selectedVideo.status !== 'processing' && selectedVideo.status !== 'completed' && (
                      <button
                        onClick={() => handleProcessVideo(selectedVideo.id)}
                        className="btn btn-primary btn-sm"
                      >
                        <Cpu size={14} /> Run AI Tracking
                      </button>
                    )}
                    {selectedVideo.status === 'completed' && (
                      <button
                        onClick={() => handleProcessVideo(selectedVideo.id)}
                        className="btn btn-secondary btn-sm"
                      >
                        <RefreshCw size={14} /> Re-process Video
                      </button>
                    )}
                    <button
                      onClick={() => handleDeleteVideo(selectedVideo.id)}
                      className="btn btn-ghost btn-sm"
                      style={{ color: 'var(--color-danger)' }}
                    >
                      <Trash2 size={14} /> Delete
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--color-text-muted)' }}>
                <FileVideo size={48} style={{ margin: '0 auto 12px auto', opacity: 0.5 }} />
                <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--color-secondary)' }}>
                  No Video Selected
                </h3>
                <p style={{ fontSize: '13px', marginTop: '4px' }}>
                  Select an uploaded video from the gallery or upload a new file.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Uploaded Videos Catalog List */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
          <div className="card-header" style={{ marginBottom: '14px' }}>
            <h3 className="card-title" style={{ fontSize: '16px' }}>
              Uploaded Videos ({videos.length})
            </h3>
            <button
              onClick={fetchVideos}
              className="btn btn-ghost btn-sm"
              title="Refresh video list"
            >
              <RefreshCw size={14} />
            </button>
          </div>

          {/* Upload Progress Bar if active */}
          {uploading && (
            <div style={{
              padding: '12px',
              backgroundColor: 'var(--color-primary-light)',
              borderRadius: 'var(--radius-md)',
              marginBottom: '14px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', fontWeight: 600, color: 'var(--color-primary)', marginBottom: '4px' }}>
                <span>Uploading Video...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div style={{ height: '6px', backgroundColor: '#DBEAFE', borderRadius: '3px', overflow: 'hidden' }}>
                <div style={{ width: `${uploadProgress}%`, height: '100%', backgroundColor: 'var(--color-primary)', transition: 'width 200ms ease' }} />
              </div>
            </div>
          )}

          {/* Video List */}
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            maxHeight: '600px',
            overflowY: 'auto'
          }}>
            {videos.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px 10px', color: 'var(--color-text-muted)' }}>
                <p style={{ fontSize: '13px' }}>No uploaded videos found.</p>
              </div>
            ) : (
              videos.map((vid) => {
                const isSelected = selectedVideo?.id === vid.id;
                const procProgress = processingStatus[vid.id]?.progress;

                return (
                  <div
                    key={vid.id}
                    onClick={() => setSelectedVideo(vid)}
                    style={{
                      padding: '12px 14px',
                      borderRadius: 'var(--radius-lg)',
                      border: '1px solid',
                      borderColor: isSelected ? 'var(--color-primary)' : 'var(--color-border)',
                      backgroundColor: isSelected ? 'var(--color-primary-light)' : '#FFFFFF',
                      cursor: 'pointer',
                      transition: 'all var(--transition-fast)'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <span style={{
                        fontSize: '13px',
                        fontWeight: 600,
                        color: isSelected ? 'var(--color-primary)' : 'var(--color-secondary)',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        maxWidth: '180px'
                      }}>
                        {vid.original_name}
                      </span>
                      {vid.status === 'completed' ? (
                        <span className="badge badge-success" style={{ fontSize: '10px', padding: '2px 6px' }}>
                          Ready
                        </span>
                      ) : vid.status === 'processing' ? (
                        <span className="badge badge-warning" style={{ fontSize: '10px', padding: '2px 6px' }}>
                          {procProgress !== undefined ? `${procProgress}%` : 'Running'}
                        </span>
                      ) : (
                        <span className="badge badge-secondary" style={{ fontSize: '10px', padding: '2px 6px' }}>
                          Queued
                        </span>
                      )}
                    </div>

                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      marginTop: '6px',
                      fontSize: '11px',
                      color: 'var(--color-text-secondary)'
                    }}>
                      <span>{(vid.file_size / (1024 * 1024)).toFixed(1)} MB</span>
                      <span>•</span>
                      <span>{vid.duration}s</span>
                      <span>•</span>
                      <span>{new Date(vid.created_at).toLocaleDateString()}</span>
                    </div>

                    {/* Mini progress bar if processing */}
                    {vid.status === 'processing' && (
                      <div style={{ height: '4px', backgroundColor: '#E2E8F0', borderRadius: '2px', marginTop: '8px', overflow: 'hidden' }}>
                        <div style={{
                          width: `${procProgress || 5}%`,
                          height: '100%',
                          backgroundColor: 'var(--color-warning)',
                          transition: 'width 300ms ease'
                        }} />
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoManagementPage;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Video,
  Eye,
  Camera,
  CheckCircle2,
  TrendingUp,
  ArrowUpRight,
  Layers,
  Clock,
  Sparkles,
  FileText,
  UploadCloud
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Line, Doughnut } from 'react-chartjs-2';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const DashboardPage = () => {
  const [stats, setStats] = useState({
    total_videos: 0,
    total_detections: 0,
    total_tracking_sessions: 0,
    total_objects_tracked: 0,
    active_camera: true,
    detection_accuracy: 94.2
  });
  const [recentDetections, setRecentDetections] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { addToast } = useToast();

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [statsRes, detectionsRes, analyticsRes] = await Promise.all([
          api.get('/dashboard/stats'),
          api.get('/dashboard/recent-detections?limit=6'),
          api.get('/analytics/summary')
        ]);
        setStats(statsRes.data);
        setRecentDetections(detectionsRes.data);
        setAnalytics(analyticsRes.data);
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
        addToast('Could not fetch latest telemetry. Using cached data.', 'warning');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [addToast]);

  // Chart 1: Detection Trends (Line Chart)
  const trendLabels = analytics?.daily_trends?.map((d) => d.date) || ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const trendValues = analytics?.daily_trends?.map((d) => d.count) || [12, 19, 28, 45, 38, 62, 54];

  const lineChartData = {
    labels: trendLabels,
    datasets: [
      {
        label: 'Detections Over Time',
        data: trendValues,
        borderColor: '#2563EB',
        backgroundColor: 'rgba(37, 99, 235, 0.1)',
        fill: true,
        tension: 0.4,
        pointBackgroundColor: '#2563EB',
        pointBorderColor: '#FFFFFF',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
      },
    ],
  };

  const lineChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#0F172A',
        titleFont: { family: 'Inter', size: 12 },
        bodyFont: { family: 'Inter', size: 12 },
        padding: 10,
        cornerRadius: 8,
      }
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { font: { family: 'Inter', size: 11 }, color: '#6B7280' }
      },
      y: {
        grid: { color: '#F1F5F9' },
        ticks: { font: { family: 'Inter', size: 11 }, color: '#6B7280', precision: 0 }
      }
    }
  };

  // Chart 2: Object Category Breakdown (Doughnut Chart)
  const categoryLabels = analytics?.object_frequencies?.slice(0, 5).map((f) => f.object_class.toUpperCase()) || ['PERSON', 'CAR', 'LAPTOP', 'DOG', 'BOTTLE'];
  const categoryValues = analytics?.object_frequencies?.slice(0, 5).map((f) => f.count) || [42, 28, 14, 10, 8];

  const doughnutChartData = {
    labels: categoryLabels,
    datasets: [
      {
        data: categoryValues,
        backgroundColor: [
          '#2563EB', // Primary Blue
          '#22C55E', // Green
          '#F59E0B', // Amber
          '#8B5CF6', // Purple
          '#06B6D4'  // Cyan
        ],
        borderWidth: 2,
        borderColor: '#FFFFFF',
        hoverOffset: 4
      }
    ]
  };

  const doughnutChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: { font: { family: 'Inter', size: 11 }, padding: 14, boxWidth: 12, usePointStyle: true }
      }
    },
    cutout: '72%'
  };

  return (
    <div className="animate-fade-in">
      {/* Top Banner / Welcome */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '28px',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--color-secondary)' }}>
            System Monitoring Dashboard
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
            Real-time telemetry, object classification, and multi-object tracking status.
          </p>
        </div>

        {/* Quick Actions Bar */}
        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={() => navigate('/live')}
            className="btn btn-primary btn-sm"
          >
            <Camera size={16} /> Live Stream
          </button>
          <button
            onClick={() => navigate('/videos')}
            className="btn btn-secondary btn-sm"
          >
            <UploadCloud size={16} /> Upload Video
          </button>
          <button
            onClick={() => navigate('/reports')}
            className="btn btn-secondary btn-sm"
          >
            <FileText size={16} /> Audit Report
          </button>
        </div>
      </div>

      {/* 4 KPI Cards (Brand Guideline: Total Videos, Total Objects Detected, Active Camera, Detection Accuracy) */}
      <div className="kpi-grid">
        {/* KPI 1: Total Videos */}
        <div className="kpi-card">
          <div className="kpi-icon-wrapper" style={{ backgroundColor: 'var(--color-primary-light)', color: 'var(--color-primary)' }}>
            <Video size={24} />
          </div>
          <div className="kpi-info">
            <span className="kpi-label">Total Videos</span>
            <span className="kpi-value">{stats.total_videos}</span>
            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
              Processed & stored
            </span>
          </div>
        </div>

        {/* KPI 2: Total Objects Detected */}
        <div className="kpi-card">
          <div className="kpi-icon-wrapper" style={{ backgroundColor: '#F0FDF4', color: 'var(--color-success)' }}>
            <Eye size={24} />
          </div>
          <div className="kpi-info">
            <span className="kpi-label">Total Objects Detected</span>
            <span className="kpi-value">{stats.total_detections}</span>
            <span style={{ fontSize: '11px', color: 'var(--color-success)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '3px', marginTop: '2px' }}>
              <TrendingUp size={12} /> {stats.total_objects_tracked} unique tracked IDs
            </span>
          </div>
        </div>

        {/* KPI 3: Active Camera */}
        <div className="kpi-card">
          <div className="kpi-icon-wrapper" style={{ backgroundColor: '#EFF6FF', color: 'var(--color-primary)' }}>
            <Camera size={24} />
          </div>
          <div className="kpi-info">
            <span className="kpi-label">Active Camera</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '4px' }}>
              <span style={{
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                backgroundColor: stats.active_camera ? 'var(--color-success)' : 'var(--color-danger)',
                display: 'inline-block',
                boxShadow: stats.active_camera ? '0 0 8px var(--color-success)' : 'none'
              }} />
              <span className="kpi-value" style={{ fontSize: '20px' }}>
                {stats.active_camera ? 'Online' : 'Offline'}
              </span>
            </div>
            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
              Webcam WebSocket ready
            </span>
          </div>
        </div>

        {/* KPI 4: Detection Accuracy */}
        <div className="kpi-card">
          <div className="kpi-icon-wrapper" style={{ backgroundColor: '#FFFBEB', color: 'var(--color-warning)' }}>
            <CheckCircle2 size={24} />
          </div>
          <div className="kpi-info">
            <span className="kpi-label">Detection Accuracy</span>
            <span className="kpi-value">{stats.detection_accuracy}%</span>
            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
              Mean confidence score
            </span>
          </div>
        </div>
      </div>

      {/* Analytics Charts Row */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '2fr 1fr',
        gap: '24px',
        marginBottom: '28px'
      }}>
        {/* Chart 1: Detection Frequency Trend */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Real-Time Detection Activity</h3>
              <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>
                Volume of detected entities across observation intervals
              </p>
            </div>
            <span className="badge badge-primary">
              <Sparkles size={12} /> YOLOv8 Live
            </span>
          </div>
          <div style={{ height: '260px', width: '100%' }}>
            <Line data={lineChartData} options={lineChartOptions} />
          </div>
        </div>

        {/* Chart 2: Object Frequency Breakdown */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Object Classes</h3>
              <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>
                Distribution across categories
              </p>
            </div>
            <span className="badge badge-secondary">Top 5</span>
          </div>
          <div style={{ height: '260px', width: '100%', position: 'relative' }}>
            <Doughnut data={doughnutChartData} options={doughnutChartOptions} />
          </div>
        </div>
      </div>

      {/* Recent Detections Table Section */}
      <div className="card">
        <div className="card-header">
          <div>
            <h3 className="card-title">Recent Detections & Tracking Events</h3>
            <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>
              Persistent track IDs and timestamped detections
            </p>
          </div>
          <button
            onClick={() => navigate('/history')}
            className="btn btn-ghost btn-sm"
          >
            View All History <ArrowUpRight size={14} />
          </button>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Snapshot</th>
                <th>Track ID</th>
                <th>Object Class</th>
                <th>Confidence</th>
                <th>Frame Number</th>
                <th>Timestamp</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recentDetections.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '36px', color: 'var(--color-text-muted)' }}>
                    No detections logged yet. Start the live camera or upload a video!
                  </td>
                </tr>
              ) : (
                recentDetections.map((det) => (
                  <tr key={det.id}>
                    <td>
                      {det.snapshot_path ? (
                        <img
                          src={`http://localhost:8000${det.snapshot_path}`}
                          alt={det.object_class}
                          style={{
                            width: '52px',
                            height: '38px',
                            objectFit: 'cover',
                            borderRadius: 'var(--radius-sm)',
                            border: '1px solid var(--color-border)'
                          }}
                        />
                      ) : (
                        <div style={{
                          width: '52px',
                          height: '38px',
                          borderRadius: 'var(--radius-sm)',
                          backgroundColor: '#F1F5F9',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: 'var(--color-text-muted)',
                          fontSize: '10px'
                        }}>
                          Frame #{det.frame_number}
                        </div>
                      )}
                    </td>
                    <td>
                      <span className="font-mono" style={{
                        padding: '2px 8px',
                        backgroundColor: '#EFF6FF',
                        color: 'var(--color-primary)',
                        borderRadius: '4px',
                        fontWeight: 600,
                        fontSize: '12px'
                      }}>
                        #{det.tracking_id}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontWeight: 600, textTransform: 'capitalize' }}>
                        {det.object_class}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <div style={{
                          flexGrow: 1,
                          height: '6px',
                          maxWidth: '70px',
                          backgroundColor: '#E5E7EB',
                          borderRadius: '3px',
                          overflow: 'hidden'
                        }}>
                          <div style={{
                            width: `${det.confidence * 100}%`,
                            height: '100%',
                            backgroundColor: det.confidence > 0.8 ? 'var(--color-success)' : 'var(--color-primary)'
                          }} />
                        </div>
                        <span className="font-mono" style={{ fontSize: '12px' }}>
                          {Math.round(det.confidence * 100)}%
                        </span>
                      </div>
                    </td>
                    <td className="font-mono">{det.frame_number}</td>
                    <td style={{ color: 'var(--color-text-secondary)', fontSize: '12px' }}>
                      {new Date(det.timestamp).toLocaleTimeString()}
                    </td>
                    <td>
                      <span className="badge badge-success">
                        <CheckCircle2 size={11} /> Verified
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;

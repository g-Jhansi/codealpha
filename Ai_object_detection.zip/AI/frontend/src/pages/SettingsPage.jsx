import React, { useState, useEffect } from 'react';
import {
  Settings,
  Camera,
  Sliders,
  User,
  Lock,
  Database,
  CheckCircle2,
  Save,
  Cpu,
  RefreshCw,
  Server
} from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

const SettingsPage = () => {
  const { user, updateProfile } = useAuth();
  const { addToast } = useToast();

  // Profile Form
  const [fullName, setFullName] = useState(user?.full_name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [savingProfile, setSavingProfile] = useState(false);

  // Password Form
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);

  // Camera & AI Settings
  const [cameraIndex, setCameraIndex] = useState(0);
  const [resolution, setResolution] = useState('1280x720');
  const [targetFps, setTargetFps] = useState(30);
  const [confThresh, setConfThresh] = useState(0.35);
  const [iouThresh, setIouThresh] = useState(0.45);
  const [savingSettings, setSavingSettings] = useState(false);
  const [systemInfo, setSystemInfo] = useState(null);

  useEffect(() => {
    if (user) {
      setFullName(user.full_name || '');
      setEmail(user.email || '');
    }

    const fetchConfig = async () => {
      try {
        const [settingsRes, infoRes] = await Promise.all([
          api.get('/settings/'),
          api.get('/settings/system-info')
        ]);
        const s = settingsRes.data;
        if (s.camera) {
          setCameraIndex(s.camera.device_index);
          setResolution(s.camera.resolution);
          setTargetFps(s.camera.target_fps);
        }
        if (s.ai) {
          setConfThresh(s.ai.confidence_threshold);
          setIouThresh(s.ai.iou_threshold);
        }
        setSystemInfo(infoRes.data);
      } catch (err) {
        console.error('Failed to load settings:', err);
      }
    };

    fetchConfig();
  }, [user]);

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await updateProfile({ full_name: fullName, email });
      addToast('Profile updated successfully!', 'success');
    } catch (err) {
      addToast(err.response?.data?.detail || 'Failed to update profile', 'danger');
    } finally {
      setSavingProfile(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      addToast('New passwords do not match', 'warning');
      return;
    }
    if (newPassword.length < 6) {
      addToast('New password must be at least 6 characters', 'warning');
      return;
    }

    setSavingPassword(true);
    try {
      await api.post('/auth/change-password', {
        current_password: currentPassword,
        new_password: newPassword
      });
      addToast('Password changed successfully!', 'success');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      addToast(err.response?.data?.detail || 'Failed to change password', 'danger');
    } finally {
      setSavingPassword(false);
    }
  };

  const handleAISettingsSubmit = async (e) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await api.put('/settings/update', {
        camera: {
          device_index: cameraIndex,
          resolution,
          target_fps: targetFps
        },
        ai: {
          confidence_threshold: confThresh,
          iou_threshold: iouThresh,
          model_name: systemInfo?.yolo_model || 'yolov8n.pt',
          tracker_type: systemInfo?.tracker || 'bytetrack.yaml'
        }
      });
      addToast('Camera and AI configuration updated successfully!', 'success');
    } catch (err) {
      addToast('Failed to save settings', 'danger');
    } finally {
      setSavingSettings(false);
    }
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{ marginBottom: '28px' }}>
        <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--color-secondary)' }}>
          System Configuration & Settings
        </h1>
        <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
          Manage AI inference thresholds, camera defaults, user profile, and system status.
        </p>
      </div>

      {/* Two-Column Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '24px'
      }}>
        {/* Column 1: AI & Camera Configuration */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">AI & Tracking Hyperparameters</h3>
              <Sliders size={18} color="var(--color-primary)" />
            </div>

            <form onSubmit={handleAISettingsSubmit}>
              {/* Confidence Threshold */}
              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <label className="form-label">Global Confidence Threshold</label>
                  <span className="font-mono" style={{ fontWeight: 600, color: 'var(--color-primary)' }}>
                    {Math.round(confThresh * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="0.95"
                  step="0.05"
                  value={confThresh}
                  onChange={(e) => setConfThresh(parseFloat(e.target.value))}
                  style={{ width: '100%', accentColor: 'var(--color-primary)' }}
                />
              </div>

              {/* IoU Threshold */}
              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <label className="form-label">NMS IoU Threshold</label>
                  <span className="font-mono" style={{ fontWeight: 600, color: 'var(--color-primary)' }}>
                    {Math.round(iouThresh * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="0.8"
                  step="0.05"
                  value={iouThresh}
                  onChange={(e) => setIouThresh(parseFloat(e.target.value))}
                  style={{ width: '100%', accentColor: 'var(--color-primary)' }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                <div className="form-group">
                  <label className="form-label">Default Camera Resolution</label>
                  <select
                    className="form-select"
                    value={resolution}
                    onChange={(e) => setResolution(e.target.value)}
                  >
                    <option value="1280x720">720p HD (1280x720)</option>
                    <option value="1920x1080">1080p FHD (1920x1080)</option>
                    <option value="640x480">480p SD (640x480)</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Target Streaming FPS</label>
                  <select
                    className="form-select"
                    value={targetFps}
                    onChange={(e) => setTargetFps(parseInt(e.target.value))}
                  >
                    <option value={15}>15 FPS (Bandwidth Saver)</option>
                    <option value={30}>30 FPS (Standard Smooth)</option>
                    <option value={60}>60 FPS (High Performance)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={savingSettings}
                className="btn btn-primary"
                style={{ width: '100%', marginTop: '8px' }}
              >
                <Save size={16} />
                {savingSettings ? 'Saving...' : 'Save AI Configuration'}
              </button>
            </form>
          </div>

          {/* System & Architecture Info */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">System & Deep Learning Architecture</h3>
              <Cpu size={18} color="var(--color-primary)" />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '13px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '8px', borderBottom: '1px solid var(--color-border)' }}>
                <span style={{ color: 'var(--color-text-secondary)' }}>AI Architecture:</span>
                <span style={{ fontWeight: 600 }}>YOLOv8 Nano (Anchor-Free Decoupled Head)</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '8px', borderBottom: '1px solid var(--color-border)' }}>
                <span style={{ color: 'var(--color-text-secondary)' }}>Tracker Algorithm:</span>
                <span style={{ fontWeight: 600 }}>ByteTrack (Kalman Filter + Hungarian Matching)</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '8px', borderBottom: '1px solid var(--color-border)' }}>
                <span style={{ color: 'var(--color-text-secondary)' }}>Backend Framework:</span>
                <span style={{ fontWeight: 600 }}>Python FastAPI 0.110+</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '8px', borderBottom: '1px solid var(--color-border)' }}>
                <span style={{ color: 'var(--color-text-secondary)' }}>Database Engine:</span>
                <span style={{ fontWeight: 600 }}>{systemInfo?.database_url || 'SQLAlchemy Relational Engine'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--color-text-secondary)' }}>System Status:</span>
                <span className="badge badge-success" style={{ padding: '2px 8px' }}>
                  <CheckCircle2 size={12} /> Operational
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Column 2: User Profile & Security */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {/* Profile Card */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">User Profile Details</h3>
              <User size={18} color="var(--color-primary)" />
            </div>

            <form onSubmit={handleProfileSubmit}>
              <div className="form-group">
                <label className="form-label">Username (Immutable)</label>
                <input
                  type="text"
                  className="form-input"
                  value={user?.username || ''}
                  disabled
                  style={{ backgroundColor: '#F8FAFC', color: 'var(--color-text-muted)' }}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input
                  type="text"
                  className="form-input"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Email Address</label>
                <input
                  type="email"
                  className="form-input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Assigned Role</label>
                <input
                  type="text"
                  className="form-input"
                  value={user?.role?.toUpperCase() || 'USER'}
                  disabled
                  style={{ backgroundColor: '#F8FAFC', color: 'var(--color-text-muted)' }}
                />
              </div>

              <button
                type="submit"
                disabled={savingProfile}
                className="btn btn-primary"
                style={{ width: '100%' }}
              >
                <Save size={16} />
                {savingProfile ? 'Updating...' : 'Update Profile'}
              </button>
            </form>
          </div>

          {/* Change Password Card */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Change Account Password</h3>
              <Lock size={18} color="var(--color-primary)" />
            </div>

            <form onSubmit={handlePasswordSubmit}>
              <div className="form-group">
                <label className="form-label">Current Password</label>
                <input
                  type="password"
                  className="form-input"
                  placeholder="••••••••"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                <div className="form-group">
                  <label className="form-label">New Password</label>
                  <input
                    type="password"
                    className="form-input"
                    placeholder="••••••••"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Confirm New Password</label>
                  <input
                    type="password"
                    className="form-input"
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={savingPassword}
                className="btn btn-secondary"
                style={{ width: '100%' }}
              >
                <Lock size={16} />
                {savingPassword ? 'Changing Password...' : 'Update Password'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;

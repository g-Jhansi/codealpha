import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Camera, Mail, ArrowLeft, CheckCircle2 } from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const { addToast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/auth/forgot-password', { email });
      setSubmitted(true);
      addToast('Reset instructions have been prepared.', 'success');
    } catch (err) {
      addToast('Unable to process reset request. Please check email.', 'danger');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'var(--color-bg)',
      padding: '24px'
    }}>
      <div className="card animate-fade-in" style={{
        maxWidth: '420px',
        width: '100%',
        padding: '36px',
        border: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-lg)',
        textAlign: 'center'
      }}>
        <div style={{
          width: '48px',
          height: '48px',
          backgroundColor: 'var(--color-primary)',
          borderRadius: '12px',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#FFFFFF',
          marginBottom: '16px'
        }}>
          <Camera size={24} />
        </div>

        <h2 style={{ fontSize: '20px', fontWeight: 700, color: 'var(--color-secondary)' }}>
          Reset Password
        </h2>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', marginTop: '4px', marginBottom: '24px' }}>
          Enter the email address registered with your account.
        </p>

        {submitted ? (
          <div style={{ padding: '20px 0' }}>
            <CheckCircle2 size={42} color="var(--color-success)" style={{ margin: '0 auto 12px auto' }} />
            <p style={{ fontSize: '14px', color: 'var(--color-secondary)', fontWeight: 500 }}>
              Password Reset Initiated
            </p>
            <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', marginTop: '6px' }}>
              For development demo, use the default password <b>Admin@123</b> or <b>User@123</b>, or update your password directly from Settings after logging in.
            </p>
            <Link to="/login" className="btn btn-primary" style={{ marginTop: '20px', width: '100%' }}>
              Return to Sign In
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit} style={{ textAlign: 'left' }}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <div style={{ position: 'relative' }}>
                <input
                  type="email"
                  className="form-input"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{ paddingLeft: '40px' }}
                  required
                />
                <Mail size={16} color="var(--color-text-muted)" style={{
                  position: 'absolute',
                  left: '14px',
                  top: '50%',
                  transform: 'translateY(-50%)'
                }} />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary"
              style={{ width: '100%', padding: '12px', marginTop: '10px' }}
            >
              {loading ? 'Sending Request...' : 'Send Reset Link'}
            </button>
          </form>
        )}

        <div style={{ marginTop: '24px' }}>
          <Link to="/login" style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            fontSize: '13px',
            color: 'var(--color-text-secondary)'
          }}>
            <ArrowLeft size={14} /> Back to Sign In
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;

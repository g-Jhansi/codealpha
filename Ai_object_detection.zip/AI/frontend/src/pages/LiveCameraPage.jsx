import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera,
  Play,
  Square,
  CameraOff,
  Crosshair,
  Sliders,
  Zap,
  Activity,
  Layers,
  Save,
  CheckCircle2,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import api, { WS_BASE_URL } from '../services/api';
import { useToast } from '../context/ToastContext';

const TARGET_CLASSES_LIST = [
  'person', 'car', 'bicycle', 'motorcycle', 'bus', 'truck',
  'dog', 'cat', 'laptop', 'cell phone', 'chair', 'bottle'
];

const LiveCameraPage = () => {
  const [streaming, setStreaming] = useState(false);
  const [devices, setDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [confThreshold, setConfThreshold] = useState(0.35);
  const [showTrajectories, setShowTrajectories] = useState(true);
  const [activeClasses, setActiveClasses] = useState(TARGET_CLASSES_LIST);
  const [telemetry, setTelemetry] = useState({
    fps: 0,
    inference_latency_ms: 0,
    total_objects: 0
  });
  const [currentDetections, setCurrentDetections] = useState([]);
  const [snapshotLoading, setSnapshotLoading] = useState(false);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const wsRef = useRef(null);
  const animFrameIdRef = useRef(null);
  const streamRef = useRef(null);
  const isSendingFrameRef = useRef(false);

  const { addToast } = useToast();

  // Enumerate Video Devices
  useEffect(() => {
    const getDevices = async () => {
      try {
        if (!navigator.mediaDevices?.enumerateDevices) {
          addToast('MediaDevices API not supported by browser', 'danger');
          return;
        }
        const devList = await navigator.mediaDevices.enumerateDevices();
        const videoDevs = devList.filter((d) => d.kind === 'videoinput');
        setDevices(videoDevs);
        if (videoDevs.length > 0 && !selectedDeviceId) {
          setSelectedDeviceId(videoDevs[0].deviceId);
        }
      } catch (err) {
        console.error('Error listing camera devices:', err);
      }
    };
    getDevices();
  }, [addToast, selectedDeviceId]);

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      stopCamera();

      const constraints = {
        video: selectedDeviceId ? { deviceId: { exact: selectedDeviceId } } : { width: 1280, height: 720 },
        audio: false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      // Initialize WebSocket connection to FastAPI
      const ws = new WebSocket(WS_BASE_URL);
      wsRef.current = ws;

      ws.onopen = () => {
        setStreaming(true);
        addToast('Live camera & AI tracking engine connected', 'success');
        startFrameLoop();
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.telemetry) {
            setTelemetry(data.telemetry);
          }
          if (data.detections) {
            setCurrentDetections(data.detections);
          }

          // If server sent annotated frame directly, draw it on canvas
          if (data.annotated_image && canvasRef.current) {
            const img = new Image();
            img.onload = () => {
              const canvas = canvasRef.current;
              if (canvas) {
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
              }
            };
            img.src = data.annotated_image;
          }

          isSendingFrameRef.current = false;
        } catch (err) {
          console.error('Error processing WebSocket message:', err);
          isSendingFrameRef.current = false;
        }
      };

      ws.onerror = (err) => {
        console.error('WebSocket error:', err);
        addToast('WebSocket connection error with AI engine', 'warning');
      };

      ws.onclose = () => {
        setStreaming(false);
      };

    } catch (err) {
      console.error('Failed to access webcam:', err);
      addToast(`Could not start webcam: ${err.message}`, 'danger');
    }
  };

  const stopCamera = () => {
    if (animFrameIdRef.current) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setStreaming(false);
    setCurrentDetections([]);
    setTelemetry({ fps: 0, inference_latency_ms: 0, total_objects: 0 });
    isSendingFrameRef.current = false;
  };

  const sendFrame = useCallback(() => {
    if (!videoRef.current || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    if (isSendingFrameRef.current) {
      return; // Previous frame inference still in flight
    }

    const video = videoRef.current;
    if (video.videoWidth === 0 || video.videoHeight === 0) {
      return;
    }

    // Offscreen canvas to extract JPEG frame
    const offscreen = document.createElement('canvas');
    offscreen.width = video.videoWidth;
    offscreen.height = video.videoHeight;
    const ctx = offscreen.getContext('2d');
    ctx.drawImage(video, 0, 0, offscreen.width, offscreen.height);

    const base64Data = offscreen.toDataURL('image/jpeg', 0.8);
    isSendingFrameRef.current = true;

    wsRef.current.send(JSON.stringify({
      image: base64Data,
      conf: confThreshold,
      iou: 0.45,
      classes: activeClasses
    }));
  }, [confThreshold, activeClasses]);

  const startFrameLoop = useCallback(() => {
    const loop = () => {
      sendFrame();
      animFrameIdRef.current = requestAnimationFrame(loop);
    };
    animFrameIdRef.current = requestAnimationFrame(loop);
  }, [sendFrame]);

  // Restart loop if dependencies change while streaming
  useEffect(() => {
    if (streaming) {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      startFrameLoop();
    }
  }, [streaming, startFrameLoop]);

  // Capture Snapshot
  const captureSnapshot = async () => {
    if (!canvasRef.current || currentDetections.length === 0) {
      addToast('No active stream or detections to capture', 'warning');
      return;
    }

    setSnapshotLoading(true);
    try {
      const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.9);
      await api.post('/live/snapshot', {
        image_base64: dataUrl,
        detections: currentDetections,
        session_name: `Live Snapshot (${new Date().toLocaleTimeString()})`
      });
      addToast(`Snapshot saved! Logged ${currentDetections.length} detections to history.`, 'success');
    } catch (err) {
      console.error('Failed to save snapshot:', err);
      addToast('Failed to save snapshot to history', 'danger');
    } finally {
      setSnapshotLoading(false);
    }
  };

  const toggleClassFilter = (cls) => {
    if (activeClasses.includes(cls)) {
      if (activeClasses.length === 1) {
        addToast('At least one target class must be active', 'warning');
        return;
      }
      setActiveClasses(activeClasses.filter((c) => c !== cls));
    } else {
      setActiveClasses([...activeClasses, cls]);
    }
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '24px',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--color-secondary)' }}>
            Live Camera Detection & Tracking
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
            Real-time YOLOv8 object recognition with ByteTrack persistent identifier assignment.
          </p>
        </div>

        {/* Primary Controls */}
        <div style={{ display: 'flex', gap: '10px' }}>
          {!streaming ? (
            <button
              onClick={startCamera}
              className="btn btn-primary"
            >
              <Play size={16} fill="currentColor" /> Start Camera
            </button>
          ) : (
            <>
              <button
                onClick={captureSnapshot}
                disabled={snapshotLoading}
                className="btn btn-secondary"
              >
                <Save size={16} /> {snapshotLoading ? 'Saving...' : 'Capture Snapshot'}
              </button>
              <button
                onClick={stopCamera}
                className="btn btn-danger"
              >
                <Square size={16} fill="currentColor" /> Stop Camera
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Grid: Video Stream (2 col) + Controls/Telemetry (1 col) */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '2.5fr 1fr',
        gap: '24px'
      }}>
        {/* Stream Display Card */}
        <div className="card" style={{ padding: '20px', display: 'flex', flexDirection: 'column' }}>
          {/* Stream Overlay Container */}
          <div style={{
            position: 'relative',
            width: '100%',
            height: '560px',
            backgroundColor: '#0F172A',
            borderRadius: 'var(--radius-lg)',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            border: '2px solid var(--color-border)'
          }}>
            {/* Hidden raw video element */}
            <video
              ref={videoRef}
              style={{ display: 'none' }}
              playsInline
              muted
            />

            {/* Canvas displaying annotated video stream with trajectories & bounding boxes */}
            <canvas
              ref={canvasRef}
              width={1280}
              height={720}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'contain',
                display: streaming ? 'block' : 'none'
              }}
            />

            {/* Offline Placeholder */}
            {!streaming && (
              <div style={{ textAlign: 'center', color: '#94A3B8', padding: '32px' }}>
                <div style={{
                  width: '64px',
                  height: '64px',
                  borderRadius: '50%',
                  backgroundColor: 'rgba(255, 255, 255, 0.08)',
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '16px'
                }}>
                  <CameraOff size={32} color="#94A3B8" />
                </div>
                <h3 style={{ color: '#F8FAFC', fontSize: '18px', fontWeight: 600 }}>
                  Camera Stream Idle
                </h3>
                <p style={{ fontSize: '13px', color: '#94A3B8', marginTop: '6px', maxWidth: '320px' }}>
                  Click "Start Camera" to grant webcam access and begin real-time multi-object detection and tracking.
                </p>
                <button
                  onClick={startCamera}
                  className="btn btn-primary btn-sm"
                  style={{ marginTop: '20px' }}
                >
                  <Play size={14} fill="currentColor" /> Launch Stream
                </button>
              </div>
            )}

            {/* Real-time Telemetry HUD (Overlaid on active video) */}
            {streaming && (
              <div style={{
                position: 'absolute',
                top: '16px',
                left: '16px',
                display: 'flex',
                gap: '8px',
                zIndex: 10
              }}>
                <div style={{
                  backgroundColor: 'rgba(15, 23, 42, 0.85)',
                  backdropFilter: 'blur(8px)',
                  padding: '6px 12px',
                  borderRadius: 'var(--radius-md)',
                  color: '#FFFFFF',
                  fontSize: '12px',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  border: '1px solid rgba(255, 255, 255, 0.1)'
                }}>
                  <Zap size={14} color="#22C55E" />
                  <span className="font-mono">{telemetry.fps} FPS</span>
                </div>

                <div style={{
                  backgroundColor: 'rgba(15, 23, 42, 0.85)',
                  backdropFilter: 'blur(8px)',
                  padding: '6px 12px',
                  borderRadius: 'var(--radius-md)',
                  color: '#FFFFFF',
                  fontSize: '12px',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  border: '1px solid rgba(255, 255, 255, 0.1)'
                }}>
                  <Activity size={14} color="#38BDF8" />
                  <span className="font-mono">{telemetry.inference_latency_ms} ms</span>
                </div>

                <div style={{
                  backgroundColor: 'rgba(15, 23, 42, 0.85)',
                  backdropFilter: 'blur(8px)',
                  padding: '6px 12px',
                  borderRadius: 'var(--radius-md)',
                  color: '#FFFFFF',
                  fontSize: '12px',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  border: '1px solid rgba(255, 255, 255, 0.1)'
                }}>
                  <Crosshair size={14} color="#F59E0B" />
                  <span>{telemetry.total_objects} Objects</span>
                </div>
              </div>
            )}
          </div>

          {/* Active Detected Classes Strip */}
          <div style={{
            marginTop: '16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '12px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-secondary)' }}>
                Active Detections:
              </span>
              {currentDetections.length === 0 ? (
                <span style={{ fontSize: '13px', color: 'var(--color-text-muted)' }}>
                  None currently in view
                </span>
              ) : (
                currentDetections.map((d, i) => (
                  <span
                    key={i}
                    className="badge badge-primary"
                    style={{ fontSize: '11px', textTransform: 'capitalize' }}
                  >
                    #{d.tracking_id} {d.object_class} ({Math.round(d.confidence * 100)}%)
                  </span>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Controls Card */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* AI Settings Box */}
          <div className="card">
            <div className="card-header" style={{ marginBottom: '16px' }}>
              <h3 className="card-title" style={{ fontSize: '16px' }}>
                AI Model & Filter Controls
              </h3>
              <Sliders size={18} color="var(--color-primary)" />
            </div>

            {/* Camera Select */}
            <div className="form-group">
              <label className="form-label">Video Input Device</label>
              <select
                className="form-select"
                value={selectedDeviceId}
                onChange={(e) => setSelectedDeviceId(e.target.value)}
                disabled={streaming}
              >
                {devices.map((d, i) => (
                  <option key={d.deviceId || i} value={d.deviceId}>
                    {d.label || `Camera Device #${i + 1}`}
                  </option>
                ))}
              </select>
            </div>

            {/* Confidence Threshold Slider */}
            <div className="form-group">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <label className="form-label">Confidence Threshold</label>
                <span className="font-mono" style={{ fontSize: '12px', fontWeight: 600, color: 'var(--color-primary)' }}>
                  {Math.round(confThreshold * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.95"
                step="0.05"
                value={confThreshold}
                onChange={(e) => setConfThreshold(parseFloat(e.target.value))}
                style={{ width: '100%', accentColor: 'var(--color-primary)', cursor: 'pointer' }}
              />
              <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
                Higher values reduce false positives.
              </span>
            </div>

            {/* Trajectory Polyline Toggle */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '12px 0',
              borderTop: '1px solid var(--color-border)',
              borderBottom: '1px solid var(--color-border)'
            }}>
              <div>
                <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-secondary)' }}>
                  Trajectory Trails
                </div>
                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
                  Renders motion paths of tracked objects
                </div>
              </div>
              <input
                type="checkbox"
                checked={showTrajectories}
                onChange={(e) => setShowTrajectories(e.target.checked)}
                style={{ width: '18px', height: '18px', accentColor: 'var(--color-primary)', cursor: 'pointer' }}
              />
            </div>

            {/* Target Classes Checklist */}
            <div style={{ marginTop: '16px' }}>
              <div style={{
                fontSize: '12px',
                fontWeight: 600,
                color: 'var(--color-secondary)',
                marginBottom: '10px'
              }}>
                Target Object Classes ({activeClasses.length} Active):
              </div>
              <div style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: '8px',
                maxHeight: '180px',
                overflowY: 'auto',
                paddingRight: '4px'
              }}>
                {TARGET_CLASSES_LIST.map((cls) => {
                  const isActive = activeClasses.includes(cls);
                  return (
                    <button
                      key={cls}
                      type="button"
                      onClick={() => toggleClassFilter(cls)}
                      style={{
                        padding: '6px 10px',
                        borderRadius: 'var(--radius-sm)',
                        border: '1px solid',
                        borderColor: isActive ? 'var(--color-primary)' : 'var(--color-border)',
                        backgroundColor: isActive ? 'var(--color-primary-light)' : '#FFFFFF',
                        color: isActive ? 'var(--color-primary)' : 'var(--color-text-secondary)',
                        fontSize: '12px',
                        fontWeight: isActive ? 600 : 500,
                        textAlign: 'left',
                        cursor: 'pointer',
                        textTransform: 'capitalize',
                        transition: 'all var(--transition-fast)'
                      }}
                    >
                      {cls}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Quick Info Box */}
          <div className="card" style={{ backgroundColor: '#F8FAFC' }}>
            <h4 style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-secondary)', marginBottom: '8px' }}>
              Multi-Object Tracking Details
            </h4>
            <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', lineHeight: 1.4 }}>
              <b>ByteTrack</b> matches detected bounding boxes with predicted Kalman Filter states across frames.
              Each object keeps its persistent ID until it exits the camera field of view.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveCameraPage;

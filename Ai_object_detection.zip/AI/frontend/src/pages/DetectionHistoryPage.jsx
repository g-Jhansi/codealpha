import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Download,
  Calendar,
  Layers,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
  FileSpreadsheet,
  FileText,
  Eye,
  X
} from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

const DetectionHistoryPage = () => {
  const [detections, setDetections] = useState([]);
  const [classes, setClasses] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  // Filters & Search
  const [search, setSearch] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [minConfidence, setMinConfidence] = useState('');
  const [sortBy, setSortBy] = useState('timestamp');
  const [sortOrder, setSortOrder] = useState('desc');

  // Preview Modal
  const [previewSnapshot, setPreviewSnapshot] = useState(null);

  const { addToast } = useToast();

  const fetchClasses = async () => {
    try {
      const res = await api.get('/detections/classes');
      setClasses(res.data);
    } catch (err) {
      console.error('Failed to fetch classes:', err);
    }
  };

  const fetchDetections = async () => {
    setLoading(true);
    try {
      const params = {
        page,
        page_size: pageSize,
        sort_by: sortBy,
        sort_order: sortOrder
      };
      if (search) params.search = search;
      if (selectedClass) params.object_class = selectedClass;
      if (minConfidence) params.min_confidence = parseFloat(minConfidence);

      const res = await api.get('/detections/', { params });
      setDetections(res.data.items);
      setTotal(res.data.total);
      setTotalPages(res.data.total_pages);
    } catch (err) {
      console.error('Failed to load detections:', err);
      addToast('Could not load detection history', 'danger');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClasses();
  }, []);

  useEffect(() => {
    fetchDetections();
  }, [page, pageSize, selectedClass, minConfidence, sortBy, sortOrder]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    fetchDetections();
  };

  const handleSortToggle = (column) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('desc');
    }
  };

  const handleExportCSV = async () => {
    try {
      const res = await api.post('/reports/generate', {
        title: 'Detection History CSV Export',
        report_type: 'csv',
        object_classes: selectedClass ? [selectedClass] : null,
        min_confidence: minConfidence ? parseFloat(minConfidence) : null
      });
      addToast('CSV export generated! Starting download...', 'success');
      window.open(`http://localhost:8000${res.data.download_url}`, '_blank');
    } catch (err) {
      addToast('Failed to export CSV', 'danger');
    }
  };

  const handleExportPDF = async () => {
    try {
      const res = await api.post('/reports/generate', {
        title: 'Detection History PDF Audit',
        report_type: 'pdf',
        object_classes: selectedClass ? [selectedClass] : null,
        min_confidence: minConfidence ? parseFloat(minConfidence) : null
      });
      addToast('PDF report generated! Starting download...', 'success');
      window.open(`http://localhost:8000${res.data.download_url}`, '_blank');
    } catch (err) {
      addToast('Failed to export PDF report', 'danger');
    }
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '24px',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--color-secondary)' }}>
            Detection History & Telemetry Logs
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
            Search, filter, inspect, and export persistent multi-object tracking records.
          </p>
        </div>

        {/* Export Buttons */}
        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={handleExportCSV} className="btn btn-secondary btn-sm">
            <FileSpreadsheet size={15} /> Export CSV
          </button>
          <button onClick={handleExportPDF} className="btn btn-primary btn-sm">
            <FileText size={15} /> Export PDF Report
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="card" style={{ marginBottom: '24px', padding: '18px 24px' }}>
        <form onSubmit={handleSearchSubmit} style={{
          display: 'grid',
          gridTemplateColumns: '2fr 1.2fr 1fr 1fr auto',
          gap: '14px',
          alignItems: 'end'
        }}>
          {/* Search Input */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Search Tracking ID or Class</label>
            <div style={{ position: 'relative' }}>
              <input
                type="text"
                className="form-input"
                placeholder="e.g. #12 or Person..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{ paddingLeft: '38px' }}
              />
              <Search size={16} color="var(--color-text-muted)" style={{
                position: 'absolute',
                left: '12px',
                top: '50%',
                transform: 'translateY(-50%)'
              }} />
            </div>
          </div>

          {/* Class Filter */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Object Class</label>
            <select
              className="form-select"
              value={selectedClass}
              onChange={(e) => {
                setSelectedClass(e.target.value);
                setPage(1);
              }}
            >
              <option value="">All Detected Classes</option>
              {classes.map((c) => (
                <option key={c} value={c}>
                  {c.toUpperCase()}
                </option>
              ))}
            </select>
          </div>

          {/* Min Confidence */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Min Confidence</label>
            <select
              className="form-select"
              value={minConfidence}
              onChange={(e) => {
                setMinConfidence(e.target.value);
                setPage(1);
              }}
            >
              <option value="">Any Confidence</option>
              <option value="0.50">50% +</option>
              <option value="0.70">70% +</option>
              <option value="0.85">85% +</option>
              <option value="0.90">90% +</option>
            </select>
          </div>

          {/* Rows Per Page */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Page Size</label>
            <select
              className="form-select"
              value={pageSize}
              onChange={(e) => {
                setPageSize(parseInt(e.target.value));
                setPage(1);
              }}
            >
              <option value={10}>10 records</option>
              <option value={25}>25 records</option>
              <option value={50}>50 records</option>
            </select>
          </div>

          {/* Search Button */}
          <button type="submit" className="btn btn-secondary" style={{ height: '42px' }}>
            <Filter size={16} /> Filter
          </button>
        </form>
      </div>

      {/* Detections Data Table */}
      <div className="card">
        <div className="card-header">
          <div>
            <h3 className="card-title" style={{ fontSize: '16px' }}>
              Historical Telemetry Logs ({total} Records Found)
            </h3>
          </div>
          <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>
            Showing page {page} of {totalPages}
          </span>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Snapshot</th>
                <th
                  onClick={() => handleSortToggle('tracking_id')}
                  style={{ cursor: 'pointer' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    Track ID <ArrowUpDown size={12} />
                  </div>
                </th>
                <th
                  onClick={() => handleSortToggle('object_class')}
                  style={{ cursor: 'pointer' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    Object Class <ArrowUpDown size={12} />
                  </div>
                </th>
                <th
                  onClick={() => handleSortToggle('confidence')}
                  style={{ cursor: 'pointer' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    Confidence <ArrowUpDown size={12} />
                  </div>
                </th>
                <th>Frame #</th>
                <th>Bounding Box [X1, Y1, X2, Y2]</th>
                <th>Source / Video</th>
                <th
                  onClick={() => handleSortToggle('timestamp')}
                  style={{ cursor: 'pointer' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    Date & Time (UTC) <ArrowUpDown size={12} />
                  </div>
                </th>
                <th>Inspect</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center', padding: '36px', color: 'var(--color-text-muted)' }}>
                    Loading telemetry records...
                  </td>
                </tr>
              ) : detections.length === 0 ? (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center', padding: '36px', color: 'var(--color-text-muted)' }}>
                    No matching detection records found.
                  </td>
                </tr>
              ) : (
                detections.map((det) => (
                  <tr key={det.id}>
                    <td>
                      {det.snapshot_path ? (
                        <img
                          src={`http://localhost:8000${det.snapshot_path}`}
                          alt={det.object_class}
                          onClick={() => setPreviewSnapshot(`http://localhost:8000${det.snapshot_path}`)}
                          style={{
                            width: '54px',
                            height: '38px',
                            objectFit: 'cover',
                            borderRadius: 'var(--radius-sm)',
                            border: '1px solid var(--color-border)',
                            cursor: 'pointer'
                          }}
                        />
                      ) : (
                        <div style={{
                          width: '54px',
                          height: '38px',
                          borderRadius: 'var(--radius-sm)',
                          backgroundColor: '#F1F5F9',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: 'var(--color-text-muted)',
                          fontSize: '10px'
                        }}>
                          Live Frame
                        </div>
                      )}
                    </td>
                    <td>
                      <span className="font-mono" style={{
                        padding: '3px 8px',
                        backgroundColor: '#EFF6FF',
                        color: 'var(--color-primary)',
                        borderRadius: '4px',
                        fontWeight: 600,
                        fontSize: '12px'
                      }}>
                        #{det.tracking_id}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontWeight: 600, textTransform: 'capitalize' }}>
                        {det.object_class}
                      </span>
                    </td>
                    <td>
                      <span className="font-mono" style={{ fontWeight: 600 }}>
                        {Math.round(det.confidence * 100)}%
                      </span>
                    </td>
                    <td className="font-mono" style={{ color: 'var(--color-text-secondary)' }}>
                      {det.frame_number}
                    </td>
                    <td className="font-mono" style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
                      [{Math.round(det.bbox_x1)}, {Math.round(det.bbox_y1)}, {Math.round(det.bbox_x2)}, {Math.round(det.bbox_y2)}]
                    </td>
                    <td style={{ fontSize: '12px', color: 'var(--color-secondary)' }}>
                      {det.video_name || 'Live Webcam'}
                    </td>
                    <td style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                      {new Date(det.timestamp).toLocaleString()}
                    </td>
                    <td>
                      {det.snapshot_path && (
                        <button
                          onClick={() => setPreviewSnapshot(`http://localhost:8000${det.snapshot_path}`)}
                          className="btn btn-ghost btn-sm"
                          style={{ padding: '4px 8px' }}
                          title="Preview Full Snapshot"
                        >
                          <Eye size={14} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginTop: '16px',
          paddingTop: '16px',
          borderTop: '1px solid var(--color-border)'
        }}>
          <div style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>
            Showing {detections.length > 0 ? (page - 1) * pageSize + 1 : 0} to {Math.min(page * pageSize, total)} of {total} entries
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page <= 1}
              className="btn btn-secondary btn-sm"
            >
              <ChevronLeft size={16} /> Previous
            </button>
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page >= totalPages}
              className="btn btn-secondary btn-sm"
            >
              Next <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Snapshot Zoom Modal */}
      {previewSnapshot && (
        <div
          onClick={() => setPreviewSnapshot(null)}
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.75)',
            backdropFilter: 'blur(8px)',
            zIndex: 999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '24px'
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="card animate-fade-in"
            style={{
              maxWidth: '850px',
              width: '100%',
              padding: '20px',
              backgroundColor: '#FFFFFF',
              position: 'relative'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 600 }}>Inspection Snapshot Preview</h3>
              <button
                onClick={() => setPreviewSnapshot(null)}
                className="btn btn-ghost btn-sm"
                style={{ padding: '4px' }}
              >
                <X size={18} />
              </button>
            </div>
            <div style={{ borderRadius: 'var(--radius-md)', overflow: 'hidden', backgroundColor: '#000000' }}>
              <img
                src={previewSnapshot}
                alt="Detection Snapshot"
                style={{ width: '100%', height: 'auto', display: 'block', objectFit: 'contain' }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DetectionHistoryPage;

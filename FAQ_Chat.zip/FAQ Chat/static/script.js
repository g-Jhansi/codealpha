document.addEventListener("DOMContentLoaded", () => {
    const chatBox = document.getElementById("chat-box");
    const userInput = document.getElementById("user-input");
    const sendBtn = document.getElementById("send-btn");

    function addMessage(text, sender) {
        const msgDiv = document.createElement("div");
        msgDiv.classList.add("message");
        msgDiv.classList.add(sender === "user" ? "user-message" : "bot-message");
        
        const p = document.createElement("p");
        p.textContent = text;
        msgDiv.appendChild(p);
        
        chatBox.appendChild(msgDiv);
        scrollToBottom();
    }

    function addTypingIndicator() {
        const indicator = document.createElement("div");
        indicator.classList.add("typing-indicator");
        indicator.id = "typing-indicator";
        indicator.innerHTML = "<span></span><span></span><span></span>";
        indicator.style.display = "block";
        chatBox.appendChild(indicator);
        scrollToBottom();
    }

    function removeTypingIndicator() {
        const indicator = document.getElementById("typing-indicator");
        if (indicator) {
            indicator.remove();
        }
    }

    function scrollToBottom() {
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    async function handleSend() {
        const text = userInput.value.trim();
        if (!text) return;

        // Display user message
        addMessage(text, "user");
        userInput.value = "";
        
        // Show typing indicator
        addTypingIndicator();

        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: text })
            });
            
            const data = await response.json();
            
            removeTypingIndicator();
            if (response.ok) {
                addMessage(data.response, "bot");
            } else {
                addMessage("Sorry, something went wrong.", "bot");
            }
        } catch (error) {
            console.error("Error communicating with server:", error);
            removeTypingIndicator();
            addMessage("Sorry, I'm having trouble connecting right now.", "bot");
        }
    }

    sendBtn.addEventListener("click", handleSend);

    userInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            handleSend();
        }
    });
});

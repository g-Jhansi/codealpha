# FAQMate Web App

A friendly and professional FAQ chatbot for answering user questions based on a predefined knowledge base.

## Features
- Minimalist and clean UI following brand guidelines.
- TF-IDF and Cosine Similarity for FAQ matching.
- Built with Flask (Python).

## Setup
1. Create a virtual environment:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python app.py
   ```
4. Open your browser and go to `http://localhost:5000`.

## Architecture
- `app.py`: Flask Web Server
- `src/`: Chatbot logic and similarity computation
- `data/`: Knowledge base storage
- `templates/` & `static/`: Frontend UI files

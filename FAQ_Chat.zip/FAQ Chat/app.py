from flask import Flask, render_template, request, jsonify
from src.chatbot import Chatbot

app = Flask(__name__)
bot = Chatbot()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_message = data.get('message', '')
    
    if not user_message:
        return jsonify({'response': "Please enter a valid question."}), 400
        
    response = bot.get_response(user_message)
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True, port=5000)

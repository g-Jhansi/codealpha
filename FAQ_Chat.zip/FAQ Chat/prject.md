FAQ-Chatbot/
│
├── data/
│   └── faqs.json
│
├── src/
│   ├── preprocess.py
│   ├── similarity.py
│   └── chatbot.py
│
├── app.py
├── requirements.txt
├── README.md
└── .gitignore
import requests
import json
import time

url = 'http://127.0.0.1:5000/chat'
headers = {'Content-Type': 'application/json'}

def test_chat(message):
    print(f"User: {message}")
    response = requests.post(url, headers=headers, data=json.dumps({"message": message}))
    if response.status_code == 200:
        print(f"Bot: {response.json().get('response')}")
    else:
        print(f"Error: {response.status_code} - {response.text}")
    print("-" * 40)

if __name__ == '__main__':
    # Wait a moment to ensure server is running
    time.sleep(2)
    test_chat("Hello")
    test_chat("What are the college timings?")
    test_chat("How do I apply?")
    test_chat("What is the meaning of life?")

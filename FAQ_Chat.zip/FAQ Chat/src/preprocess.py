import json
import os

def load_faqs(file_path):
    """Loads FAQs from a JSON file."""
    if not os.path.exists(file_path):
        return []
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def get_questions(faqs):
    """Extracts only the questions from the FAQ list."""
    return [faq['question'] for faq in faqs]

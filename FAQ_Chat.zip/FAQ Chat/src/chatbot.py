from src.preprocess import load_faqs, get_questions
from src.similarity import find_best_match

class Chatbot:
    def __init__(self, data_path='data/faqs.json'):
        self.faqs = load_faqs(data_path)
        self.questions = get_questions(self.faqs)
        self.threshold = 0.4 # Minimum similarity score to be considered a match
        
    def get_response(self, user_input):
        user_input = user_input.strip().lower()
        
        # Polite greeting handling
        greetings = ["hi", "hello", "hey", "greetings", "good morning", "good afternoon"]
        if user_input in greetings:
            return "Hi! 👋 I'm FAQMate. How can I help you today?"
            
        if not self.faqs:
            return "Sorry, the knowledge base is currently empty."

        best_match_idx, score = find_best_match(user_input, self.questions)
        
        if score >= self.threshold:
            return self.faqs[best_match_idx]['answer']
        else:
            return "Sorry, I couldn't find a relevant answer in the available FAQs. Please try asking another question."

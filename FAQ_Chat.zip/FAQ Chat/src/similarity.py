from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def find_best_match(user_query, questions):
    """
    Finds the most similar question using TF-IDF and Cosine Similarity.
    Returns the index of the best match and the similarity score.
    """
    if not questions:
        return -1, 0.0

    vectorizer = TfidfVectorizer().fit(questions + [user_query])
    vectors = vectorizer.transform(questions + [user_query])
    
    # Cosine similarity between user query (last element) and all questions
    cosine_sim = cosine_similarity(vectors[-1], vectors[:-1]).flatten()
    
    best_match_idx = cosine_sim.argmax()
    best_score = cosine_sim[best_match_idx]
    
    return best_match_idx, best_score
